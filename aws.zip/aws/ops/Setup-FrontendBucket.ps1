<#!
.SYNOPSIS
  Automate frontend S3 bucket policy, website config, and (optional) build + sync for TeamsTranscriptCleaner.

.DESCRIPTION
  Idempotent script to:
    * Normalize working directory (fixes .NET relative path mismatch)
    * Generate / refresh a public read bucket policy (only GetObject)
    * Remove S3 public access block (if present) for simple static website hosting
    * Apply static website config (index.html / error.html)
    * Optionally run npm install + build for the frontend (Vite) and sync dist/ to S3
    * Output the website URL

  Designed for PowerShell 5.1+ (Windows) but compatible with pwsh Core.

.PARAMETER BucketName
  Target S3 bucket name (must already exist; this script does NOT create it for safety).

.PARAMETER Region
  AWS region. Default: ap-northeast-1

.PARAMETER FrontendPath
  Path to frontend project root (contains package.json). Default: ..\frontend relative to aws/.

.PARAMETER SkipBuild
  Skip the build step (use existing dist/).

.PARAMETER SyncOnly
  Skip build even if not built; only perform S3 sync (implies SkipBuild).

.PARAMETER DryRun
  Show actions but do not modify AWS nor write files.

.PARAMETER VerbosePolicy
  Print generated policy JSON.

.PARAMETER ForcePolicy
  Re-apply bucket policy even if unchanged.

.PARAMETER CacheMaxAge
  Cache-Control max-age (seconds) for uploaded objects (excluding source maps). Default 300.

.PARAMETER ExtraNpmArgs
  Extra arguments passed to `npm install` (e.g. --no-audit).

.EXAMPLE
  powershell -ExecutionPolicy Bypass -File .\ops\Setup-FrontendBucket.ps1 -BucketName "teams-transcript-cleaner-frontend-123456789012-ap-northeast-1"

.EXAMPLE
  # Derive bucket from CloudFormation stack output then run
  $Bucket = aws cloudformation describe-stacks --stack-name teams-transcript-cleaner --query "Stacks[0].Outputs[?OutputKey=='FrontendBucketName'].OutputValue" --output text
  powershell -ExecutionPolicy Bypass -File .\ops\Setup-FrontendBucket.ps1 -BucketName $Bucket -VerbosePolicy

.NOTES
  For production hardening consider: CloudFront + OAC (then remove public bucket policy), stricter IAM, versioned asset paths.
#>
[CmdletBinding()] param(
  [Parameter(Mandatory=$true)][string]$BucketName,
  [string]$Region = 'ap-northeast-1',
  [string]$FrontendPath = '..\frontend',
  [switch]$SkipBuild,
  [switch]$SyncOnly,
  [switch]$DryRun,
  [switch]$VerbosePolicy,
  [switch]$ForcePolicy,
  [switch]$CreateBucket,
  [int]$CacheMaxAge = 300,
  [string]$ExtraNpmArgs = ''
)

$ErrorActionPreference = 'Stop'
$script:Started = Get-Date
Write-Host "== Setup-FrontendBucket.ps1 :: $(Get-Date -Format o) ==" -ForegroundColor Cyan

# 1. Normalize working directory for .NET relative path resolution
$psPath = (Get-Location).ProviderPath
if ([Environment]::CurrentDirectory -ne $psPath) {
  Write-Host "Syncing process working directory: '$($psPath)'" -ForegroundColor DarkGray
  [Environment]::CurrentDirectory = $psPath
}

# 2. Resolve paths (auto-detect fallback if initial not found)
$FrontendFull = $null
try {
  if (Test-Path $FrontendPath) { $FrontendFull = (Resolve-Path $FrontendPath).ProviderPath }
} catch {}
if (-not $FrontendFull) {
  $candidates = @('.\frontend','..\frontend','..\aws\frontend')
  foreach ($c in $candidates) {
    if (Test-Path $c) { try { $FrontendFull = (Resolve-Path $c).ProviderPath; break } catch {} }
  }
}
if (-not $FrontendFull) { throw "FrontendPath not found: tried '$FrontendPath' and candidates (.\\frontend, ..\\frontend, ..\\aws\\frontend). Use -FrontendPath to specify explicitly." }
$PolicyPath = Join-Path $psPath 'site-policy.json'
$DistPath   = Join-Path $FrontendFull 'dist'

Write-Host "Bucket        : $BucketName" -ForegroundColor Yellow
Write-Host "Region        : $Region" -ForegroundColor Yellow
Write-Host "Frontend Path : $FrontendFull" -ForegroundColor Yellow
Write-Host "Policy Path   : $PolicyPath" -ForegroundColor Yellow
Write-Host "SkipBuild     : $SkipBuild  SyncOnly: $SyncOnly  DryRun: $DryRun  ForcePolicy: $ForcePolicy" -ForegroundColor Yellow

# Early bucket name validation (avoid cryptic AWS CLI errors)
if ($BucketName -like '*<ACCOUNT>*' -or $BucketName -match '[<> ]') {
  throw "BucketName '$BucketName' still contains placeholder tokens (e.g. <ACCOUNT>) or illegal characters <>/space. Replace <ACCOUNT> with your 12-digit AWS Account ID: $(aws sts get-caller-identity --query Account --output text 2>$null)"
}
if ($BucketName -notmatch '^[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]$') {
  throw "BucketName '$BucketName' is invalid. Must be 3-63 chars, lowercase letters, numbers, dots, and hyphens, cannot start/end with dot or hyphen."
}

if ($SyncOnly -and -not $SkipBuild) { $SkipBuild = $true }

function Write-Step($msg) { Write-Host "[STEP] $msg" -ForegroundColor Green }
function Write-Skip($msg) { Write-Host "[SKIP] $msg" -ForegroundColor DarkYellow }
function Write-Info($msg) { Write-Host "[INFO] $msg" -ForegroundColor DarkCyan }
function Write-Warn($msg) { Write-Warning $msg }

# 3. Verify bucket exists
Write-Step "Verifying bucket exists"
$bucketExists = $false
try {
  if (-not $DryRun) { aws s3api head-bucket --bucket $BucketName 2>$null | Out-Null }
  $bucketExists = $true
} catch {
  if ($CreateBucket -and -not $DryRun) {
    Write-Info "Bucket not found. Creating because -CreateBucket specified."
    # Create bucket (add location constraint except for us-east-1)
    if ($Region -eq 'us-east-1') {
      aws s3api create-bucket --bucket $BucketName 2>$null | Out-Null
    } else {
      aws s3api create-bucket --bucket $BucketName --create-bucket-configuration LocationConstraint=$Region 2>$null | Out-Null
    }
    $bucketExists = $true
    Start-Sleep -Seconds 2
  } else {
    throw "Bucket '$BucketName' not found or not accessible. Use -CreateBucket to create automatically or create manually: aws s3 mb s3://$BucketName --region $Region"
  }
}

# 4. Generate policy JSON
Write-Step "Generating bucket policy JSON"
$policyObj = [pscustomobject]@{
  Version   = '2012-10-17'
  Statement = @(
    [pscustomobject]@{
      Sid       = 'AllowPublicReadForWebsiteAssets'
      Effect    = 'Allow'
      Principal = '*'
      Action    = @('s3:GetObject')
      Resource  = "arn:aws:s3:::$BucketName/*"
    }
  )
}
$policyJson = $policyObj | ConvertTo-Json -Depth 5
if ($VerbosePolicy) { Write-Info "Policy JSON:\n$policyJson" }

if (-not $DryRun) {
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($PolicyPath, $policyJson, $utf8NoBom)
  Write-Info "Policy file written (UTF-8 no BOM): $PolicyPath"
} else {
  Write-Skip "DryRun: not writing policy file"
}

# 5. Remove public access block (if any)
Write-Step "Ensuring bucket public access block is cleared (for static website)"
if (-not $DryRun) {
  try { aws s3api delete-public-access-block --bucket $BucketName 2>$null | Out-Null } catch { Write-Warn "Could not delete public access block: $_" }
  try {
    $pab = aws s3api get-public-access-block --bucket $BucketName 2>$null | Out-String
    if ($pab) { Write-Info "Current PublicAccessBlock configuration AFTER delete attempt: $pab" }
    else { Write-Info "No PublicAccessBlock configuration present (good)." }
  } catch { Write-Info "PublicAccessBlock status not retrievable (may be absent)" }
} else { Write-Skip "DryRun: public access block not modified" }

# 6. Apply / compare bucket policy
Write-Step "Applying bucket policy (diff aware)"
$needsUpdate = $true
if (-not $ForcePolicy) {
  try {
    if (-not $DryRun) {
      $existingRaw = aws s3api get-bucket-policy --bucket $BucketName 2>$null | Out-String
      if ($existingRaw) {
        $existingObj  = $existingRaw | ConvertFrom-Json
        $existingJson = ($existingObj | ConvertTo-Json -Depth 5)
        if ($existingJson -eq $policyJson) {
          $needsUpdate = $false
          Write-Info "Existing policy already matches (use -ForcePolicy to re-apply)."
        }
      }
    }
  } catch {
    Write-Info "No existing policy or retrieval failed; will apply new policy."
  }
}
if ($needsUpdate) {
  if (-not $DryRun) {
    aws s3api put-bucket-policy --bucket $BucketName --policy (Get-Content $PolicyPath -Raw) | Out-Null
    Write-Info "Bucket policy applied."
    try {
      $polStatus = aws s3api get-bucket-policy-status --bucket $BucketName 2>$null | Out-String
      if ($polStatus) { Write-Info "Bucket policy status: $polStatus" }
    } catch { Write-Info "Could not retrieve bucket policy status (permission or propagation delay)." }
  }
  else { Write-Skip "DryRun: would apply bucket policy" }
} else {
  Write-Skip "No policy update necessary." }

# 7. Configure static website
Write-Step "Configuring static website (index.html / error.html)"
if (-not $DryRun) {
  aws s3 website "s3://$BucketName/" --index-document index.html --error-document error.html | Out-Null
  Write-Info "Website configuration ensured."
} else { Write-Skip "DryRun: website config not changed" }

# 8. Build frontend (if required)
Write-Step "Frontend build phase"
if ($SyncOnly) {
  Write-Skip "SyncOnly: skipping build"
} elseif ($SkipBuild) {
  Write-Skip "SkipBuild specified: not building"
} else {
  if (-not (Test-Path (Join-Path $FrontendFull 'package.json'))) {
    Write-Warn "package.json not found at $FrontendFull; skipping build"
  } else {
    if ($DryRun) { Write-Skip "DryRun: would run npm install & build" }
    else {
      Push-Location $FrontendFull
      try {
        if (-not (Test-Path 'node_modules')) {
          Write-Info "Running npm install $ExtraNpmArgs"
          npm install $ExtraNpmArgs
        } else { Write-Info "node_modules exists: skipping npm install" }
        Write-Info "Running npm run build"
        npm run build
      } finally { Pop-Location }
    }
  }
}

# 9. Sync dist/
Write-Step "Sync dist/ to S3"
if (-not (Test-Path $DistPath)) {
  Write-Warn "dist path does not exist: $DistPath (build may have been skipped or failed)"
} else {
  if ($DryRun) { Write-Skip "DryRun: would sync $DistPath to s3://$BucketName/" }
  else {
    $cacheCtl = "public,max-age=$CacheMaxAge"
    Write-Info "Syncing with Cache-Control=$cacheCtl"
    aws s3 sync $DistPath "s3://$BucketName/" --delete --cache-control $cacheCtl --exclude "*.map" | Out-Null
    Write-Info "Sync complete."
  }
}

# 10. Emit website URL
$WebsiteUrl = "http://$BucketName.s3-website-$Region.amazonaws.com"
Write-Host "Website URL: $WebsiteUrl" -ForegroundColor Magenta

$elapsed = (Get-Date) - $script:Started
Write-Host "== Completed in $([int]$elapsed.TotalSeconds)s (DryRun:$DryRun) ==" -ForegroundColor Cyan
