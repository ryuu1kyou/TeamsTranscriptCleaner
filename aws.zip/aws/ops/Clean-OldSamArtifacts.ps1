<#!
.SYNOPSIS
  Prune old SAM deployment artifacts in the explicit artifact bucket while keeping the currently referenced Lambda code object and the most recent N historical objects.

.DESCRIPTION
  CloudFormation (after SAM transform) stores the Lambda function Code S3 bucket/key in the *processed* template.
  The Lambda service itself does NOT expose S3Bucket/S3Key in `aws lambda get-function` (hence null in your query),
  because after deployment the code is copied internally. Therefore you must inspect the processed template or
  keep artifacts by policy. This script:
    1. Retrieves the processed template for the given stack.
    2. Extracts the active Lambda artifact S3 bucket/key.
    3. Lists objects under the given prefix in the artifact bucket.
    4. Preserves: (a) active artifact, (b) newest <Keep> objects (by LastModified), (c) newest template file.
    5. Deletes the remainder (unless -DryRun specified).

.PARAMETER StackName
  CloudFormation stack name (SAM application).

.PARAMETER Profile
  AWS credential profile name.

.PARAMETER ArtifactBucket
  S3 bucket storing SAM build artifacts (as configured in samconfig.toml).

.PARAMETER Prefix
  Object key prefix used by SAM for this stack.

.PARAMETER Keep
  Number of newest objects (in addition to the active one) to retain.

.PARAMETER DryRun
  If supplied, only shows what would be deleted.

.EXAMPLE
  ./Clean-OldSamArtifacts.ps1 -Keep 5 -Profile sso-admin -Verbose

.NOTES
  Safe to schedule (e.g. weekly). For extra safety enable S3 Bucket Versioning + a lifecycle rule.
#>
param(
  [string]$StackName = "teams-transcript-cleaner",
  [string]$Profile = "sso-admin",
  [string]$ArtifactBucket = "ttc-sam-artifacts-358734095190-ap-northeast-1",
  [string]$Prefix = "teams-transcript-cleaner/",
  [int]$Keep = 5,
  [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Write-Verbose "Fetching processed template for stack '$StackName'..."
$templateJson = aws cloudformation get-template --stack-name $StackName --template-stage Processed --profile $Profile --output json | ConvertFrom-Json
if(-not $templateJson.TemplateBody) { throw "Failed to obtain processed template body" }

# Support both shapes: Code: { S3Bucket, S3Key } or directly S3Bucket/S3Key
$codeNode = $templateJson.TemplateBody.Resources.CleanerFunction.Properties.Code
if(-not $codeNode) { throw "Cannot locate CleanerFunction Code node in processed template." }

$activeBucket = $codeNode.S3Bucket
$activeKey    = $codeNode.S3Key
if(-not $activeBucket -or -not $activeKey) { throw "Processed template missing S3Bucket/S3Key (unexpected)." }

Write-Host "Active artifact:" -ForegroundColor Cyan
Write-Host "  Bucket: $activeBucket" 
Write-Host "  Key   : $activeKey"

if($activeBucket -ne $ArtifactBucket) {
  Write-Warning "Active artifact bucket ($activeBucket) != specified ArtifactBucket ($ArtifactBucket). Using active bucket for safety."
  $ArtifactBucket = $activeBucket
}

Write-Verbose "Listing objects in bucket '$ArtifactBucket' prefix '$Prefix'..."
$objects = aws s3api list-objects-v2 --bucket $ArtifactBucket --prefix $Prefix --query 'Contents[].{Key:Key,LastModified:LastModified,Size:Size}' --profile $Profile | ConvertFrom-Json
if(-not $objects) {
  Write-Host "No objects found under prefix. Exiting."; exit 0
}

# Sort newest first
$sorted = $objects | Sort-Object {[DateTime]$_.LastModified} -Descending

# Identify template files separately (.template)
$templates = $sorted | Where-Object { $_.Key -like '*.template' }
$newestTemplate = $templates | Select-Object -First 1

# Build retention set
$retain = [System.Collections.Generic.HashSet[string]]::new()
$retain.Add($activeKey) | Out-Null
$sorted | Select-Object -First $Keep | ForEach-Object { $retain.Add($_.Key) | Out-Null }
if($newestTemplate) { $retain.Add($newestTemplate.Key) | Out-Null }

$toDelete = $sorted | Where-Object { -not $retain.Contains($_.Key) }

Write-Host "Retention summary:" -ForegroundColor Cyan
Write-Host "  Active artifact........: $activeKey"
Write-Host "  Newest $Keep additional: " ($sorted | Select-Object -First $Keep | ForEach-Object Key -join ', ')
if($newestTemplate) { Write-Host "  Newest template.........: $($newestTemplate.Key)" }
Write-Host "  Total objects..........: $($objects.Count)"
Write-Host "  Will delete............: $($toDelete.Count)" -ForegroundColor Yellow

if($toDelete.Count -eq 0) { Write-Host "Nothing to delete."; exit 0 }

if($DryRun) {
  Write-Host "DryRun: Objects that WOULD be deleted:" -ForegroundColor Yellow
  $toDelete | ForEach-Object { Write-Host "  $_.Key" }
  exit 0
}

Write-Host "Deleting..." -ForegroundColor Yellow
foreach($obj in $toDelete) {
  aws s3api delete-object --bucket $ArtifactBucket --key $obj.Key --profile $Profile | Out-Null
  Write-Host "Deleted: $($obj.Key)" -ForegroundColor DarkGray
}

Write-Host "Completed cleanup. Remaining objects:"
aws s3api list-objects-v2 --bucket $ArtifactBucket --prefix $Prefix --query 'Contents[].Key' --profile $Profile
