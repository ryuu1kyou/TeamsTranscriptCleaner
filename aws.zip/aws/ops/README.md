## ops/ ディレクトリについて

開発時に利用した IAM / Identity Center (SSO) 用の補助スクリプトやポリシーファイルをここに集約しました。\
本番デプロイ (SAM + Lambda) には不要であり、将来的には別インフラリポジトリへ移動予定です。

含まれるファイル (抜粋):

- `Create-PermissionSets.ps1` : 権限セット初期作成補助スクリプト
- `inline_policy_developer.json` : Developer 用インラインポリシー定義
- `Clean-OldSamArtifacts.ps1` : SAM アーティファクト S3 バケット整理
- `Setup-FrontendBucket.ps1` : フロントエンド S3 (ポリシー/Website/ビルド/同期) 自動化

### Setup-FrontendBucket.ps1 クイックスタート

```powershell
cd aws
powershell -ExecutionPolicy Bypass -File .\ops\Setup-FrontendBucket.ps1 `
	-BucketName "teams-transcript-cleaner-frontend-<ACCOUNT>-ap-northeast-1" `
	-Region ap-northeast-1 -VerbosePolicy
```

オプション:

| スイッチ             | 説明                                                    |
| -------------------- | ------------------------------------------------------- |
| `-SkipBuild`         | 既存 `dist/` を利用 (ビルド省略)                        |
| `-SyncOnly`          | ビルド完全省略 + 同期のみ ( `-SkipBuild` 内包 )         |
| `-DryRun`            | AWS / ファイル非変更で手順確認                          |
| `-ForcePolicy`       | 既存ポリシーが同一でも再適用                            |
| `-CacheMaxAge <sec>` | `Cache-Control: public,max-age=<sec>` 上書き (既定:300) |

将来 CloudFront + OAC を導入したら `AllowPublicReadForWebsiteAssets` ポリシーは撤去し、`Setup-FrontendBucket.ps1` も分岐拡張してください。

> セキュリティ注意: このフォルダはあくまで例示 / ローカル利用目的。CI/CD や自動適用パイプラインには直接取り込まないでください。
