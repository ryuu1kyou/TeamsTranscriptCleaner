$RegionTarget = "ap-northeast-1"
$InstanceArn = aws sso-admin list-instances --region $RegionTarget --query "Instances[0].InstanceArn" --output text
$defs = @(
  @{Name="AdminAccess"; Managed=@("arn:aws:iam::aws:policy/AdministratorAccess"); Inline=$null},
  @{Name="PowerUser"; Managed=@("arn:aws:iam::aws:policy/PowerUserAccess"); Inline=$null},
  @{Name="ReadOnly"; Managed=@("arn:aws:iam::aws:policy/ReadOnlyAccess"); Inline=$null},
  @{Name="Developer"; Managed=@("arn:aws:iam::aws:policy/PowerUserAccess"); Inline="inline_policy_developer.json"}
)

foreach ($d in $defs) {
  $exists = $false
  $psList = aws sso-admin list-permission-sets --instance-arn $InstanceArn --region $RegionTarget --query "PermissionSets[]" --output text 2>$null
  if ($psList) {
    foreach ($arn in $psList -split "`t") {
      if (-not $arn) { continue }
      $n = aws sso-admin describe-permission-set --instance-arn $InstanceArn --permission-set-arn $arn --region $RegionTarget --query "PermissionSet.Name" --output text 2>$null
      if ($n -eq $d.Name) { $exists = $true; Write-Host "[SKIP] $($d.Name) already exists: $arn"; break }
    }
  }
  if ($exists) { continue }

  $createdArn = aws sso-admin create-permission-set `
    --instance-arn $InstanceArn `
    --name $($d.Name) `
    --session-duration PT8H `
    --relay-state "https://console.aws.amazon.com/" `
    --region $RegionTarget `
    --query "PermissionSet.PermissionSetArn" --output text

  Write-Host "[CREATE] $($d.Name): $createdArn"

  foreach ($mp in $d.Managed) {
    aws sso-admin attach-managed-policy-to-permission-set `
      --instance-arn $InstanceArn `
      --permission-set-arn $createdArn `
      --managed-policy-arn $mp `
      --region $RegionTarget | Out-Null
    Write-Host "  + ManagedPolicy: $mp"
  }

  if ($d.Inline) {
    aws sso-admin put-inline-policy-to-permission-set `
      --instance-arn $InstanceArn `
      --permission-set-arn $createdArn `
      --inline-policy file://$($d.Inline) `
      --region $RegionTarget | Out-Null
    Write-Host "  + InlinePolicy: $($d.Inline)"
  }

  Start-Sleep -Seconds 1
}

Write-Host "List:"
$psArns = aws sso-admin list-permission-sets --instance-arn $InstanceArn --region $RegionTarget --query "PermissionSets[]" --output text
$psArns