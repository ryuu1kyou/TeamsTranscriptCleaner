# Teams Transcript Cleaner - Operations Runbook

Last Updated: 2025-09-13

## 1. Overview

Serverless transcript correction / grammar / summarization API.

Architecture: API Gateway (HTTP API) → Lambda (`CleanerFunction`) → OpenAI API + DynamoDB + SSM Parameter Store.

Region: `ap-northeast-1`

CloudFormation Stack: `teams-transcript-cleaner`

Key Outputs (stack):

- `ApiEndpoint`
- `FunctionName`
- `CorrectionsTableName`
- `OpenAIParameterName` (`/prod/openai/api_key`)

## 2. API Usage

Endpoint: `POST {ApiEndpoint}/correct`

Request JSON body fields:

- `text` (string, required)
- `mode` (string, optional: `misspelling` | `grammar` | `summarize`; default `misspelling`)
- `user_custom_prompt` (string, optional)
- `correction_csv` (string, optional, raw CSV data with two columns: original, replacement)
- `model` (string, optional, e.g. `gpt-4o`)

PowerShell example:

```powershell
$ENDPOINT = "https://xxxx.execute-api.ap-northeast-1.amazonaws.com"
$payload = @{ text = "Ths is a smple txt."; mode = "misspelling" } | ConvertTo-Json
Invoke-RestMethod -Uri "$ENDPOINT/correct" -Method POST -Body $payload -ContentType 'application/json'
```

Success Response Fields:

- `request_id`
- `mode` / `model`
- `chunks[]` (each chunk: `chunk_index`, `original_tokens_est`, `corrected`, `cost_usd`)
- `total_cost_usd`
- `final_text`

## 3. Deployment

Uses `samconfig.toml`.

```powershell
cd aws
sam build
sam deploy --no-confirm-changeset --capabilities CAPABILITY_IAM
```

Manual confirm (show changeset):

```powershell
sam deploy
```

Retrieve outputs:

```powershell
aws cloudformation describe-stacks `
  --stack-name teams-transcript-cleaner `
  --region ap-northeast-1 `
  --profile sso-admin `
  --query "Stacks[0].Outputs"
```

## 4. OpenAI API Key Management (SSM Parameter Store)

Parameter: `/prod/openai/api_key` (SecureString)

Update / Rotate:

```powershell
aws ssm put-parameter `
  --name /prod/openai/api_key `
  --value "sk-NEWKEY" `
  --type SecureString `
  --overwrite `
  --region ap-northeast-1 `
  --profile sso-admin
```

Lambda refresh: next cold start automatically, or force by editing configuration (no code change needed).

History:

```powershell
aws ssm get-parameter-history `
  --name /prod/openai/api_key `
  --region ap-northeast-1 `
  --profile sso-admin
```

(Old values are not shown in plaintext; retain secure copy externally if rollback required.)

## 5. DynamoDB Table

Primary key: `request_id` (PK) + `chunk_index` (SK)
Attributes: `mode`, `model`, `cost_usd` (Number/Decimal), `original_tokens_est` (Number), `timestamp`.
PITR: Enabled.

Quick scan:

```powershell
aws dynamodb scan `
  --table-name <CorrectionsTableName> `
  --max-items 10 `
  --region ap-northeast-1 `
  --profile sso-admin
```

## 6. Logging & Monitoring

Get function name:

```powershell
$FUNC = aws cloudformation describe-stacks --stack-name teams-transcript-cleaner `
  --region ap-northeast-1 --profile sso-admin `
  --query "Stacks[0].Outputs[?OutputKey=='FunctionName'].OutputValue" --output text
```

Tail logs:

```powershell
aws logs tail /aws/lambda/$FUNC --since 10m --follow --region ap-northeast-1 --profile sso-admin
```

Cold start prints: `LOADED_DEPENDENCIES {openai: 1.43.0, ...}` for pinned dependency verification.

Recommended (future) alarms:

- Lambda Errors > 0 for 5m
- Error rate > 5%
- Duration p95 sustained increase
- DynamoDB ThrottleCount > 0

## 7. Common Failure Scenarios

| Symptom                           | Likely Cause                                   | Diagnosis                                   | Temporary Mitigation                        |
| --------------------------------- | ---------------------------------------------- | ------------------------------------------- | ------------------------------------------- |
| 500 key resolution failed         | Missing / renamed SSM param or IAM deny        | Lambda logs; check IAM policy parameter ARN | Recreate parameter; deploy fix              |
| 500 Model invocation failed       | OpenAI API error / invalid model / key revoked | Log `detail` field                          | Rotate key; correct model                   |
| Decimal/float serialization error | New float field written directly               | Identify commit & log                       | Wrap with `Decimal(str(value))`             |
| Timeout                           | Large text / model latency                     | Check Duration metric & input size          | Reduce chunk ratio (0.4→0.3); raise timeout |
| Cost spike                        | Burst usage / long inputs                      | Invocations + DynamoDB item volume          | Add WAF / rate limit /                      |

## 8. Dependency Upgrades

File: `aws/src/requirements.txt` (pinned versions).
Procedure:

1. Edit version(s)
2. `sam build`
3. `sam deploy`
4. Verify `LOADED_DEPENDENCIES` in new cold start log
   Rollback: revert file in git & redeploy.

## 9. Rollback (Code)

```powershell
git log -n 5 --oneline
git checkout <previous_commit>
sam build
sam deploy --no-confirm-changeset --capabilities CAPABILITY_IAM
```

If stack drift or failed update (rollback disabled): fix resource, redeploy or delete failed stack manually then redeploy.

## 10. Security Notes

- API key never stored in code or template; fetched at runtime.
- IAM policy restricted to specific SSM parameter ARN.
- Consider: WAF for rate limiting / IP allow, API key auth, structured JSON logs.

## 11. Backlog / Enhancements

- Structured logging (Embedded Metrics Format)
- Retrieval endpoint (GET by `request_id`)
- Rate limiting / WAF
- Cost aggregation job (daily)
- CSV uploads via S3 pre-signed URL

## 12. Health Check Script

```powershell
$STACK="teams-transcript-cleaner"
$REGION="ap-northeast-1"
$PROFILE="sso-admin"
$FUNC = aws cloudformation describe-stacks --stack-name $STACK --region $REGION --profile $PROFILE `
  --query "Stacks[0].Outputs[?OutputKey=='FunctionName'].OutputValue" --output text
$API  = aws cloudformation describe-stacks --stack-name $STACK --region $REGION --profile $PROFILE `
  --query "Stacks[0].Outputs[?OutputKey=='ApiEndpoint'].OutputValue" --output text

$payload = @{ text = 'Health ping.' } | ConvertTo-Json
$result = Invoke-RestMethod -Uri "$API/correct" -Method POST -Body $payload -ContentType 'application/json'
Write-Host "Function: $FUNC"; Write-Host "API: $API"; $result | ConvertTo-Json -Depth 6
```

## 13. Versioning Policy (Suggested)

- Feature branch: `feature/<short-desc>`
- Merge to `main` after review
- Tag release: `git tag prod-YYYYMMDD-N && git push --tags`
- Track dependency changes with commit prefix `[deps]`

## 14. Quick Reference Commands

| Purpose     | Command                                                                        |
| ----------- | ------------------------------------------------------------------------------ |
| Deploy      | `sam build && sam deploy --no-confirm-changeset --capabilities CAPABILITY_IAM` |
| Tail logs   | `aws logs tail /aws/lambda/$FUNC --since 5m --follow`                          |
| Get outputs | `aws cloudformation describe-stacks --query "Stacks[0].Outputs"`               |
| Rotate key  | `aws ssm put-parameter --overwrite`                                            |
| Scan table  | `aws dynamodb scan --max-items 5`                                              |
| Health test | (See Section 12)                                                               |

---

End of Runbook.

## 15. Frontend (Static) Deployment

The stack now provisions an S3 static website bucket (`FrontendBucket`). Files live in `aws/frontend/` and are ignored for Lambda packaging.

### 15.1 Initial Upload

```powershell
$STACK="teams-transcript-cleaner"
$REGION="ap-northeast-1"
$PROFILE="sso-admin"
$FRONTEND_BUCKET = aws cloudformation describe-stacks `
  --stack-name $STACK --region $REGION --profile $PROFILE `
  --query "Stacks[0].Outputs[?OutputKey=='FrontendBucketName'].OutputValue" --output text

aws s3 sync aws/frontend/ s3://$FRONTEND_BUCKET/ --delete --acl public-read
```

Website URL (unauthenticated static):

```powershell
aws cloudformation describe-stacks `
  --stack-name $STACK --region $REGION --profile $PROFILE `
  --query "Stacks[0].Outputs[?OutputKey=='FrontendWebsiteURL'].OutputValue" --output text
```

### 15.2 Cache Busting

- Simple: change `config.js` or append query string when loading in browser.
- Advanced: integrate build pipeline producing hashed filenames.

### 15.3 API Endpoint Configuration

Set API endpoint inside `aws/frontend/config.js` via `window.__TTC_API_BASE` or let runtime prompt user.

### 15.4 Hardening (Future)

- Replace public S3 website with CloudFront distribution (OAC) & restrict bucket public policy.
- Enable HTTPS custom domain via ACM.

### 15.5 Cleanup / Versioning

To roll back: re-sync previous snapshot of `frontend/` directory from git history.

---

## 16. React (Vite) Frontend Build & Deploy

A React + Vite + TypeScript scaffold is located under `aws/frontend/`.

Key files:

- `package.json` (scripts & dependencies)
- `vite.config.ts` (base `./` so relative asset paths work on S3 website hosting)
- `src/` (components, pages, styles)

### 16.1 One-Time Dependency Install (Local Build Environment)

Requirements: Node.js 18+ (recommend LTS). Use PowerShell from repo root.

```powershell
cd aws/frontend
npm ci   # if lock file later added; currently use npm install
# or
npm install
```

### 16.2 Development Mode (Local)

```powershell
npm run dev
```

Default: `http://localhost:5173` (Vite). Use the API Gateway endpoint value in the UI's API base input.

### 16.3 Production Build

```powershell
npm run build   # outputs to dist/
```

Artifacts placed in `aws/frontend/dist/` (git-ignored recommended). Verify `index.html` references relative `./assets/...` paths (handled by `base: './'`).

### 16.4 Deploy Build Artifacts to S3

Sync ONLY the `dist/` directory (preferred) so dev sources aren't published:

```powershell
$STACK="teams-transcript-cleaner"
$REGION="ap-northeast-1"
$PROFILE="sso-admin"
$FRONTEND_BUCKET = aws cloudformation describe-stacks `
  --stack-name $STACK --region $REGION --profile $PROFILE `
  --query "Stacks[0].Outputs[?OutputKey=='FrontendBucketName'].OutputValue" --output text

aws s3 sync aws/frontend/dist/ s3://$FRONTEND_BUCKET/ --delete --acl public-read
```

### 16.5 Cache Invalidation Strategy

Because filenames are not yet hashed, browsers may cache aggressively:

- After deploy, you can append a query string: `?v=20250913` when loading the site.
- Future improvement: enable hashed file names (`build.manifest`, or rely on Vite default when using content hashing) and add a CloudFront distribution for proper cache invalidation via `CreateInvalidation`.

### 16.6 Environment / API Endpoint Handling

Current approach: user inputs API base in the top bar, persisted to `localStorage`.
Optional (future) patterns:

1. Build-time variable: set `VITE_API_BASE` before `npm run build` (e.g. `set VITE_API_BASE=https://...; npm run build`). Then read via `import.meta.env.VITE_API_BASE` in code.
2. Runtime `config.js`: host a small `config.js` in S3 that sets `window.__TTC_API_BASE` and load it before the app bundle.

### 16.7 Troubleshooting Build

| Issue            | Cause             | Fix                                                                           |
| ---------------- | ----------------- | ----------------------------------------------------------------------------- |
| 404 on assets    | Wrong base path   | Ensure `base: './'` in `vite.config.ts`                                       |
| Blank page in S3 | Using SPA routes  | Keep single-page; do not navigate to client routes without CloudFront rewrite |
| CORS errors      | API denies origin | Adjust API Gateway CORS / Lambda response headers                             |
| Mixed Content    | HTTP API endpoint | Use HTTPS API endpoint from stack output                                      |

### 16.8 Next Improvements (Optional)

- Add CloudFront with OAC to remove public bucket policy
- Enable content hashing (`build.rollupOptions.output.entryFileNames`) for long-term caching
- Add simple GitHub Action: on push to `main` run `npm ci && npm run build && aws s3 sync dist/ ...`
- Integrate error boundary & toast notifications in UI

---

### 16.9 Runtime Config (`config.js`)

Added a `public/config.js` (deployed to S3 root) that assigns `window.__TTC_CONFIG = { API_BASE: ... }`.

Load order: because `index.html` will include `<script src="/config.js"></script>` (add if not present) before the Vite bundle, the React app reads it on start.

API Base precedence in code:

1. `window.__TTC_CONFIG.API_BASE` (if defined & non-empty)
2. `localStorage['ttc_api_base']`
3. Manual input (empty initial state)

Update workflow (no rebuild needed):

```powershell
$STACK="teams-transcript-cleaner"
$REGION="ap-northeast-1"
$PROFILE="sso-admin"
$FRONTEND_BUCKET = aws cloudformation describe-stacks `
  --stack-name $STACK --region $REGION --profile $PROFILE `
  --query "Stacks[0].Outputs[?OutputKey=='FrontendBucketName'].OutputValue" --output text

@'
// config.js generated at deploy time
window.__TTC_CONFIG = {
  API_BASE: "https://xxxx.execute-api.ap-northeast-1.amazonaws.com"
};
'@ | Set-Content -Encoding UTF8 temp-config.js

aws s3 cp temp-config.js s3://$FRONTEND_BUCKET/config.js --acl public-read
Remove-Item temp-config.js
```

If browsers cache it, append version query parameter to `<script>` tag or use `aws s3 cp --cache-control "no-cache"`.

---

## 17. React UI Parity vs Original Streamlit

The original prototype (`ui_components/app.py`) implemented text correction, diff visualization, CSV-based misspelling rules, cost display, and manual post-edit workflows. The React SPA reproduces (and in some areas extends) those behaviors while remaining a static deployable frontend.

| Feature (Streamlit)                                | React Implementation                        | Notes                                                                    |
| -------------------------------------------------- | ------------------------------------------- | ------------------------------------------------------------------------ |
| API key handling (env)                             | Not needed client-side                      | Handled in Lambda via SSM; client supplies only text & options           |
| Mode selection (misspelling / grammar / summarize) | `<select>` in `CorrectionForm`              | Same semantics; CSV only shown in misspelling mode                       |
| Custom prompt                                      | `Custom Prompt` textarea                    | Passed as `user_custom_prompt`                                           |
| CSV upload / edit                                  | Textarea (manual paste)                     | File upload omitted to keep static simplicity (can add later)            |
| CSV validation (header 誤,正)                      | Implemented (blocking run)                  | Mirrors Streamlit checks for header & data rows                          |
| Token / cost pre-estimate                          | Not shown yet                               | Could be added by calling a light endpoint or client estimation function |
| Chunked processing progress bar                    | Not shown                                   | Backend returns chunks after completion (future: streaming/progress)     |
| Result final text                                  | `ResultPanel` + EditorsPanel corrected area | Stored in state; editable area separate from raw JSON panel              |
| Diff view                                          | EditorsPanel diff toggle (char-level LCS)   | Simpler than Streamlit's color spans but similar visual cues             |
| Copy corrected → original                          | Button `Copy Corrected → Original`          | Matches semantic of continued refinement loop                            |
| Final download                                     | `Download Final` button                     | Uses Blob & timestamp naming                                             |
| Per-chunk detail                                   | `ChunkTable`                                | Jump button selects first matching substring                             |
| Session cost accumulation                          | Last run + session total                    | Streamlit total-cost persistence not yet replicated                      |
| Layout (two columns editors)                       | Responsive flex layout                      | Collapses gracefully on narrow screens                                   |
| Runtime API endpoint override                      | `config.js` + localStorage                  | Enables environment switching w/out rebuild                              |

### 17.1 Remaining Gaps / Options

- Token & cost pre-estimate widget (optional small endpoint or client approximation)
- File upload (TXT / CSV) using `<input type="file">` + FileReader
- Better diff (line-level + intra-line highlights; virtualization for very long texts)
- Chunk jump accuracy (backend could include `offset_start`)
- CloudFront + hashed assets for production hardening
- Persist cumulative cost in localStorage (e.g., `ttc_cost_total`)

### 17.2 Adding Token / Cost Estimate (Future Sketch)

1. Create lightweight Lambda (or extend existing) with a `POST /estimate` to return token count & cost based on model.
2. Call it on text change debounce (e.g., 800ms) and display below transcript textarea.
3. Avoid triggering for extremely large inputs continuously (length guard).

### 17.3 Enhancing Chunk Jump

If Lambda returns `chunks[].offset_start` (character offset in final_text), then the jump logic becomes a direct selection rather than substring search, eliminating ambiguity when repeated prefixes exist.

---

## 18. Local Development (SAM) & `local-env.json`

Operational steps for running the Lambda & API locally with the SAM CLI. This complements the README (developer view) with operator notes.

### 18.1 Files

| Path                           | Role                                                                          |
| ------------------------------ | ----------------------------------------------------------------------------- |
| `aws/local-env.json`           | Environment variable definitions used by `sam local` commands (`--env-vars`). |
| `aws/events/sample_event.json` | Example invocation payload for direct `sam local invoke`.                     |

`local-env.json` structure (example):

```jsonc
{
  "CleanerFunction": {
    "OPENAI_BASE_URL": "https://api.openai.com/v1",
    "OPENAI_MODEL": "gpt-4o",
    "DDB_TABLE_NAME": "dev-Corrections",
    "OPENAI_API_KEY": "sk-local-dev-or-dummy"
  }
}
```

Notes:

- Match the logical function name key (`CleanerFunction`) to the resource logical ID in the SAM template.
- Avoid committing real secrets; replace with placeholders or load from host env at runtime (future enhancement: use `Parameters` + `sam local start-api --parameter-overrides`).

### 18.2 Start Local API

```powershell
cd aws
sam build
sam local start-api --env-vars local-env.json
```

Test request (PowerShell):

```powershell
$payload = @{ text = 'Local test sentence.'; mode='misspelling' } | ConvertTo-Json
Invoke-RestMethod -Uri "http://127.0.0.1:3000/correct" -Method POST -Body $payload -ContentType 'application/json'
```

### 18.3 Single Function Invocation

```powershell
sam local invoke CleanerFunction --event events/sample_event.json --env-vars local-env.json
```

### 18.4 Frontend Against Local API

1. Start React dev server (see Section 16): `npm run dev` inside `aws/frontend`.
2. In the UI top bar, set API base to `http://127.0.0.1:3000` (or use runtime `config.js`).
3. Run a correction; observe logs in the SAM terminal window.

### 18.5 DynamoDB Local (Optional)

To avoid hitting the real table, you can spin up DynamoDB Local (future pattern). Then add an env var `DYNAMODB_ENDPOINT=http://127.0.0.1:8000` in `local-env.json` and adjust the client initialization in code to honor it (not yet implemented—tracked in backlog idea).

### 18.6 Best Practices

- Keep `local-env.json` minimal; only variables actually consumed by code.
- Do not commit real API keys; prefer a placeholder & set an override in your shell session if needed.
- Rebuild (`sam build`) after dependency or template changes before re-starting `start-api`.
- Use separate table names (e.g., prefix with `dev-`) to prevent polluting production data.

### 18.7 Troubleshooting

| Symptom                 | Cause                         | Action                                             |
| ----------------------- | ----------------------------- | -------------------------------------------------- |
| 403 from OpenAI         | Invalid test key              | Set a valid key in env or mock the call            |
| Env var missing in code | Mismatch logical function key | Verify JSON top-level key equals Lambda logical ID |
| Changes not reflected   | Not rebuilt                   | Run `sam build` again                              |
| Port already in use     | Another dev server            | Use `--port 3100` or free the port                 |

---
