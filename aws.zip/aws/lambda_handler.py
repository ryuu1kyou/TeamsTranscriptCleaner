import json
import os
import uuid
import base64
from typing import Any, Dict, List

from processing.openai_api import correct_text
from processing.csv_parser import parse_csv_text
from processing.token_manager import split_text, get_max_tokens_for_model, estimate_cost

"""Lambda handler for transcript cleaning.

Adds runtime fallback to fetch OPENAI_API_KEY from SSM Parameter Store when
the environment variable is not already provided (production pattern).
"""

# Optional imports (boto3 provided in Lambda, may be absent locally)
try:  # pragma: no cover
    import boto3  # type: ignore
except Exception:  # pragma: no cover
    boto3 = None  # type: ignore

# DynamoDB resource (optional)
_dynamodb = None
if boto3:
    try:  # pragma: no cover
        _dynamodb = boto3.resource("dynamodb")
    except Exception:
        _dynamodb = None

_ssm_client = None  # lazy init
_cached_api_key: str | None = None

def _ensure_api_key():
    """Ensure OPENAI_API_KEY is available.

    Resolution order:
      1. If already present in env -> return
      2. If cached (previous SSM fetch) -> re-set env and return
      3. If boto3 missing -> raise instructive error
      4. Attempt to fetch from SSM. Supports multiple candidate names:
         - Environment variable OPENAI_PARAM_NAME may contain a single name or a list
           separated by comma/semicolon/whitespace. First successful fetch wins.
         - If OPENAI_PARAM_NAME unset, fallback list is tried in order.

    Fallback candidate list (if OPENAI_PARAM_NAME not set):
      /prod/openai/api_key
      /openai/api_key
      /prod/OPENAI_API_KEY
      /openai/OPENAI_API_KEY
    """
    global _ssm_client, _cached_api_key
    if os.getenv("OPENAI_API_KEY"):
        return
    if _cached_api_key:
        os.environ["OPENAI_API_KEY"] = _cached_api_key
        return
    if not boto3:
        raise RuntimeError(
            "OPENAI_API_KEY not set and boto3 unavailable to fetch from SSM. Set the env var or install boto3."
        )
    if _ssm_client is None:
        _ssm_client = boto3.client("ssm")  # type: ignore

    raw_names = os.getenv("OPENAI_PARAM_NAME")
    if raw_names:
        # Split on comma / semicolon / whitespace
        parts = [p.strip() for chunk in raw_names.replace(";", ",").split(",") for p in chunk.split() if p.strip()]
        candidates = parts or [raw_names.strip()]
    else:
        candidates = [
            "/prod/openai/api_key",
            "/openai/api_key",
            "/prod/OPENAI_API_KEY",
            "/openai/OPENAI_API_KEY",
        ]

    errors: List[str] = []
    for name in candidates:
        try:  # pragma: no cover - network/ssm
            value = _ssm_client.get_parameter(Name=name, WithDecryption=True)["Parameter"]["Value"]  # type: ignore
        except Exception as e:  # pragma: no cover
            errors.append(f"{name}: {e}")
            continue
        _cached_api_key = value
        os.environ["OPENAI_API_KEY"] = value
        return

    raise RuntimeError(
        "Failed to load OpenAI API key from SSM. Tried: " + ", ".join(candidates) + ". Errors: " + " | ".join(errors)
    )

def _get_table():
    table_name = os.getenv("CORRECTIONS_TABLE")
    if table_name and _dynamodb:
        return _dynamodb.Table(table_name)
    return None

SUPPORTED_MODES = {"misspelling", "grammar", "summarize"}

def _response(status: int, body: Dict[str, Any]):
    return {"statusCode": status, "headers": {"Content-Type": "application/json"}, "body": json.dumps(body, ensure_ascii=False)}


def lambda_handler(event, context):  # type: ignore
    # Guarantee API key presence (env or SSM)
    try:
        _ensure_api_key()
    except Exception as e:
        return _response(500, {"error": "API key resolution failed", "detail": str(e)})
    # If invoked via API Gateway HTTP (HttpApi), body may be str (JSON) or already parsed.
    if isinstance(event, dict) and "requestContext" in event and "body" in event:
        body_raw = event.get("body", "")
        if event.get("isBase64Encoded"):
            try:
                body_raw = base64.b64decode(body_raw).decode("utf-8")
            except Exception:
                return _response(400, {"error": "Invalid base64 body"})
        try:
            payload = json.loads(body_raw or "{}")
        except json.JSONDecodeError:
            return _response(400, {"error": "Body must be valid JSON"})
    else:
        payload = event if isinstance(event, dict) else {}

    text = payload.get("text") or payload.get("input_text")
    mode = payload.get("mode", "misspelling")
    user_prompt = payload.get("user_custom_prompt", "")
    correction_csv = payload.get("correction_csv", "")  # raw CSV string
    model = payload.get("model") or os.getenv("DEFAULT_MODEL", "gpt-4o")

    if not text:
        return _response(400, {"error": "'text' is required"})
    if mode not in SUPPORTED_MODES:
        return _response(400, {"error": f"Unsupported mode '{mode}'"})

    corrections = []
    if correction_csv:
        corrections = parse_csv_text(correction_csv)

    # Determine chunking threshold
    max_model_tokens = get_max_tokens_for_model(model)
    # Reserve some tokens for system prompt and completion (heuristic 20%)
    per_chunk_limit = int(max_model_tokens * 0.4)  # conservative to avoid overrun
    chunks = split_text(text, max_tokens=per_chunk_limit)

    request_id = str(uuid.uuid4())
    results: List[Dict[str, Any]] = []
    aggregate_cost = 0.0
    combined_output_parts: List[str] = []

    for idx, chunk in enumerate(chunks):
        try:
            corrected, cost = correct_text(
                processing_mode=mode,
                user_custom_prompt=user_prompt,
                input_text=chunk,
                correction_words=corrections,
                model=model,
            )
        except Exception as e:  # openai or other error
            return _response(500, {"error": f"Model invocation failed at chunk {idx}", "detail": str(e)})

        aggregate_cost += cost
        combined_output_parts.append(corrected)
        results.append({
            "chunk_index": idx,
            "original_tokens_est": estimate_cost(chunk, model)["tokens"],
            "corrected": corrected,
            "cost_usd": round(cost, 6)
        })

    final_text = "\n\n".join(combined_output_parts)

    # Optional persistence
    table = _get_table()
    if table:
        with table.batch_writer(overwrite_by_pkeys=["request_id", "chunk_index"]) as batch:  # type: ignore
            for r in results:
                item = {
                    "request_id": request_id,
                    "chunk_index": r["chunk_index"],
                    "mode": mode,
                    "model": model,
                    "cost_usd": r["cost_usd"],
                    "original_tokens_est": r["original_tokens_est"],
                    "timestamp": context.aws_request_id if context else "local",
                }
                batch.put_item(Item=item)

    response_body = {
        "request_id": request_id,
        "mode": mode,
        "model": model,
        "chunks": results,
        "total_cost_usd": round(aggregate_cost, 6),
        "final_text": final_text,
    }

    return _response(200, response_body)
