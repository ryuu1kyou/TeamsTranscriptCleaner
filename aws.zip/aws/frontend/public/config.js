// Runtime configuration injected at deploy time.
// You can edit and re-upload this file to S3 without rebuilding the app.
// Example usage in code: window.__TTC_CONFIG?.API_BASE
window.__TTC_CONFIG = {
  // Set your API base endpoint (no trailing slash). Example:
  // API_BASE: "https://xxxx.execute-api.ap-northeast-1.amazonaws.com",
  API_BASE: "https://nbt4bb5n0l.execute-api.ap-northeast-1.amazonaws.com",
  // Optional future fields: DEFAULT_MODEL: "gpt-4o"
};
