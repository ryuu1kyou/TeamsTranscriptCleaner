(function(){
  const apiBaseSpan = document.getElementById('apiBase');
  let apiBase = window.__TTC_API_BASE || '';
  if(!apiBase){
    apiBase = localStorage.getItem('ttc_api_base') || '';
  }
  if(!apiBase){
    apiBase = prompt('Enter API Endpoint (e.g. https://xxxx.execute-api.ap-northeast-1.amazonaws.com)') || '';
  }
  apiBase = apiBase.replace(/\/$/, '');
  localStorage.setItem('ttc_api_base', apiBase);
  apiBaseSpan.textContent = apiBase || '(not set)';

  const qs = sel => document.querySelector(sel);
  const runBtn = qs('#runBtn');
  const clearBtn = qs('#clearBtn');
  const textEl = qs('#text');
  const modeEl = qs('#mode');
  const promptEl = qs('#prompt');
  const csvEl = qs('#csv');
  const modelEl = qs('#model');
  const statusEl = qs('#status');
  const jsonEl = qs('#json');
  const finalEl = qs('#final');
  const metaEl = qs('#meta');

  function setStatus(msg, kind='info'){ statusEl.textContent = msg; statusEl.className = kind; }
  function showJSON(obj){ jsonEl.textContent = JSON.stringify(obj, null, 2); }
  function disableUI(dis){ runBtn.disabled = dis; }

  async function callApi(){
    const text = textEl.value.trim();
    if(!apiBase){ setStatus('API endpoint not configured', 'error'); return; }
    if(!text){ setStatus('No transcript text provided', 'error'); return; }
    disableUI(true); setStatus('Requesting...'); finalEl.value=''; jsonEl.textContent=''; metaEl.textContent='';
    const payload = {
      text,
      mode: modeEl.value,
      user_custom_prompt: promptEl.value || '',
      correction_csv: csvEl.value || '',
      model: modelEl.value || 'gpt-4o'
    };
    let resp, data;
    try {
      resp = await fetch(apiBase + '/correct', {
        method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload)
      });
    } catch(err){
      setStatus('Network error: ' + err, 'error'); disableUI(false); return;
    }
    try { data = await resp.json(); } catch(e){ data = { raw: await resp.text() }; }
    showJSON(data);
    if(!resp.ok){ setStatus('Error '+resp.status, 'error'); disableUI(false); return; }
    finalEl.value = data.final_text || '';
    metaEl.textContent = `Request: ${data.request_id} | Total Cost: ${data.total_cost_usd}`;
    setStatus('Success', 'ok');
    disableUI(false);
  }

  runBtn.addEventListener('click', callApi);
  clearBtn.addEventListener('click', () => { textEl.value=''; finalEl.value=''; jsonEl.textContent=''; metaEl.textContent=''; setStatus('Cleared'); });
})();