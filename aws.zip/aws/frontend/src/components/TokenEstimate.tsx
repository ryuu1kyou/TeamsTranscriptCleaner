import React, { useMemo } from 'react';

interface Props {
  text: string;
  mode: string;
  model: string;
  prompt: string;
  csv: string;
}

// Rough pricing table (USD per 1K tokens). Adjust as needed.
const PRICING: Record<string, { input: number; output: number }> = {
  'gpt-4o': { input: 0.005, output: 0.015 },
  'gpt-4o-mini': { input: 0.00015, output: 0.0006 },
  'gpt-4o-mini-translate': { input: 0.00015, output: 0.0006 },
};

// Very naive token estimate: ~1 token per 4 chars (ASCII-ish) fallback.
function estimateTokens(str: string): number {
  if (!str) return 0;
  // heuristic: split on whitespace + punctuation, approximate token count
  const len = str.length;
  return Math.max(1, Math.round(len / 4));
}

export const TokenEstimate: React.FC<Props> = ({ text, mode, model, prompt, csv }) => {
  const { inputTokens, outputTokens, totalCost } = useMemo(() => {
    const modelKey = PRICING[model] ? model : 'gpt-4o';
    const price = PRICING[modelKey];
    // Compose a pseudo prompt payload similar to backend usage pattern
    const basePrompt = prompt.trim();
    const csvPart = mode === 'misspelling' ? csv : '';
    const fullInput = [basePrompt, csvPart, text].filter(Boolean).join('\n');
    const inputTokens = estimateTokens(fullInput);
    // Assume output tokens roughly 30% of input for grammar/misspelling, 10% for summarize
    const ratio = mode === 'summarize' ? 0.1 : 0.3;
    const outputTokens = Math.max(1, Math.round(inputTokens * ratio));
    const cost =
      (inputTokens / 1000) * price.input + (outputTokens / 1000) * price.output;
    return { inputTokens, outputTokens, totalCost: cost };
  }, [text, mode, model, prompt, csv]);

  return (
    <div
      className="token-estimate"
      style={{ fontSize: '0.75rem', opacity: 0.85, marginTop: '0.5rem' }}
    >
      <strong>Estimate:</strong>{' '}
      <span>
        in {inputTokens} tok / out {outputTokens} tok ≈ ${(totalCost || 0).toFixed(4)} USD
      </span>
    </div>
  );
};

export default TokenEstimate;
