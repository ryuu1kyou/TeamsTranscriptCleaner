import React, { useEffect, useState, useCallback } from 'react';
import { CorrectionForm } from '../sections/CorrectionForm';
import { ResultPanel } from '../sections/ResultPanel';
import { ApiConfigBar } from '../sections/ApiConfigBar';
import { EditorsPanel } from '../sections/EditorsPanel';
import { ChunkTable } from '../sections/ChunkTable';
import { CorrectionResult, CorrectionRequestPayload, ApiErrorResponse } from '../types';

export const App: React.FC = () => {
  const [apiBase, setApiBase] = useState<string>(getInitialApiBase());
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CorrectionResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [originalText, setOriginalText] = useState('');
  const [correctedText, setCorrectedText] = useState('');
  // Persisted session cumulative cost (across reloads) in localStorage
  const [sessionCost, setSessionCost] = useState(() => {
    const v = localStorage.getItem('ttc_session_cost');
    return v ? Number(v) || 0 : 0;
  });
  const [lastRunCost, setLastRunCost] = useState(0);
  const [toasts, setToasts] = useState<
    {
      id: string;
      type: 'error' | 'info' | 'success';
      msg: string;
      ts: number;
    }[]
  >([]);

  const pushToast = useCallback(
    (msg: string, type: 'error' | 'info' | 'success' = 'info', ttlMs = 5000) => {
      const id = Math.random().toString(36).slice(2);
      const toast = { id, type, msg, ts: Date.now() };
      setToasts((arr) => [...arr, toast]);
      if (ttlMs > 0) {
        setTimeout(() => {
          setToasts((arr) => arr.filter((t) => t.id !== id));
        }, ttlMs);
      }
    },
    []
  );

  function getInitialApiBase(): string {
    // Order of precedence:
    // 1. Runtime config.js (window.__TTC_CONFIG.API_BASE)
    // 2. Previously saved localStorage value
    // 3. Empty string (user must input)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const cfg = (window as any).__TTC_CONFIG;
    if (cfg && typeof cfg.API_BASE === 'string' && cfg.API_BASE.trim()) {
      return cfg.API_BASE.trim();
    }
    const stored = localStorage.getItem('ttc_api_base');
    return stored || '';
  }

  const handleCall = useCallback(
    async (payload: CorrectionRequestPayload) => {
      setError(null);
      setLoading(true);
      setResult(null);
      try {
        if (!apiBase) throw new Error('API Base 未設定');
        const resp = await fetch(`${apiBase.replace(/\/$/, '')}/correct`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload),
        });
        const data: Partial<CorrectionResult> & ApiErrorResponse = await resp
          .json()
          .catch(() => ({ raw: 'Invalid JSON' }) as { raw: string });
        if (!resp.ok || !data || !data.request_id) {
          const errMsg = `HTTP ${resp.status}: ${
            (data && (data.error || data.detail)) || 'Unknown error'
          }`;
          setError(errMsg);
          pushToast(errMsg, 'error');
        } else {
          const typed: CorrectionResult = data as CorrectionResult;
          setResult(typed);
          setOriginalText(payload.text);
          const newFinal = typed.final_text || '';
          setCorrectedText(newFinal);
          const runCost = Number(typed.total_cost_usd || 0);
          setLastRunCost(runCost);
          setSessionCost((c) => {
            const next = c + runCost;
            try {
              localStorage.setItem('ttc_session_cost', String(next));
            } catch {}
            return next;
          });
          pushToast('完了', 'success', 2500);
        }
      } catch (e: unknown) {
        const em = e instanceof Error ? e.message : String(e);
        setError(em);
        pushToast(em, 'error');
      } finally {
        setLoading(false);
      }
    },
    [apiBase, pushToast]
  );

  const copyCorrectedToOriginal = () => {
    setOriginalText(correctedText);
  };

  const resetSessionCost = () => {
    setSessionCost(0);
    try {
      localStorage.removeItem('ttc_session_cost');
    } catch {}
  };

  const downloadFinal = useCallback(() => {
    const blob = new Blob([correctedText], { type: 'text/plain' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    const now = new Date();
    const stamp = now.toISOString().replace(/[-:]/g, '').replace(/\..+/, '').slice(0, 15);
    a.download = `final_transcript_${stamp}.txt`;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }, [correctedText]);

  const jumpToChunk = (idx: number) => {
    if (!result?.chunks || !result.chunks[idx]) return;
    const chunk = result.chunks[idx];
    const preview = String(chunk.corrected || '').slice(0, 20);
    // naive search of preview inside corrected text
    if (preview) {
      const pos = correctedText.indexOf(preview);
      if (pos >= 0) {
        // create a temporary hidden textarea ref inside EditorsPanel via query
        const editable = document.querySelector(
          '.editor-col textarea:last-of-type'
        ) as HTMLTextAreaElement | null;
        if (editable) {
          editable.focus();
          editable.setSelectionRange(pos, pos + preview.length);
          // scroll smoothly
          editable.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
      }
    }
  };

  // Persisted meta (mode/model/prompt/csv) tracking for keyboard rerun
  const META_KEY = 'ttc_meta_v1';
  const getPersistedMeta = (): {
    mode: string;
    model: string;
    prompt: string;
    csv: string;
  } => {
    try {
      const raw = localStorage.getItem(META_KEY);
      if (raw) {
        const p = JSON.parse(raw);
        if (
          p &&
          typeof p.mode === 'string' &&
          typeof p.model === 'string' &&
          typeof p.prompt === 'string' &&
          typeof p.csv === 'string'
        ) {
          return p;
        }
      }
    } catch {}
    return { mode: 'misspelling', model: 'gpt-4o', prompt: '', csv: '誤,正' };
  };
  const [metaSnapshot, setMetaSnapshot] = useState(getPersistedMeta());

  const handleMetaChange = useCallback(
    (m: { mode: string; model: string; prompt: string; csv: string }) => {
      setMetaSnapshot(m);
    },
    []
  );

  // Keyboard shortcuts: Ctrl+Enter => run (if original text present & not loading), Ctrl+S => download
  useEffect(() => {
    function handler(e: KeyboardEvent) {
      const isMac = navigator.platform.toLowerCase().includes('mac');
      const ctrl = isMac ? e.metaKey : e.ctrlKey;
      if (!ctrl) return;
      if (e.key === 'Enter') {
        if (!loading && originalText.trim()) {
          e.preventDefault();
          // Use persisted meta snapshot for consistent rerun
          const ms = metaSnapshot;
          const payload: CorrectionRequestPayload = {
            text: originalText,
            mode: ms.mode || 'misspelling',
            user_custom_prompt: ms.prompt || '',
            correction_csv: ms.mode === 'misspelling' ? ms.csv : undefined,
            model: ms.model || 'gpt-4o',
          };
          handleCall(payload);
        }
      } else if (e.key.toLowerCase() === 's') {
        if (correctedText.trim()) {
          e.preventDefault();
          downloadFinal();
        }
      }
    }
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [loading, originalText, correctedText, metaSnapshot, handleCall, downloadFinal]);

  return (
    <div className="app-shell">
      <ApiConfigBar apiBase={apiBase} onChange={setApiBase} />
      <main className="layout" style={{ flexDirection: 'column' }}>
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap' }}>
          <CorrectionForm
            onSubmit={handleCall}
            disabled={loading}
            onTextChange={setOriginalText}
            initialText={originalText}
            onMetaChange={handleMetaChange}
          />
          <ResultPanel loading={loading} result={result} error={error} />
        </div>
        <EditorsPanel
          original={originalText}
          corrected={correctedText}
          onCorrectedChange={setCorrectedText}
        />
        {result?.chunks && <ChunkTable chunks={result.chunks} onJump={jumpToChunk} />}
        <div className="actions" style={{ marginTop: '0.75rem' }}>
          <button
            onClick={copyCorrectedToOriginal}
            disabled={!correctedText.trim()}
            title="訂正後テキストを訂正前にコピー"
          >
            Copy Corrected → Original
          </button>
          <button
            onClick={downloadFinal}
            disabled={!correctedText.trim()}
            className="secondary"
          >
            Download Final
          </button>
          <div
            className="status"
            style={{
              background: '#fff',
              display: 'flex',
              gap: '0.5rem',
              alignItems: 'center',
              flexWrap: 'wrap',
            }}
          >
            <span>Last: ${lastRunCost.toFixed(4)}</span>
            <span>Total: ${sessionCost.toFixed(4)}</span>
            <button
              className="mini"
              type="button"
              onClick={resetSessionCost}
              title="セッション累計コストをリセット"
            >
              Reset Cost
            </button>
          </div>
        </div>
      </main>
      <footer className="footer">API: {apiBase || '(未設定)'} / &copy; 2025</footer>
      {/* Toast Container */}
      <div className="toast-container">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.type}`}>
            <span className="toast-msg">{t.msg}</span>
            <button
              className="toast-close"
              onClick={() => setToasts((arr) => arr.filter((x) => x.id !== t.id))}
            >
              ×
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
