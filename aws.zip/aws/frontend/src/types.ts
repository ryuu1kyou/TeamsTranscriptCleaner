// Shared type definitions for API contracts and component props

export interface CorrectionChunk {
  chunk_index: number;
  original_tokens_est?: number;
  corrected: string;
  cost_usd?: number;
  // Future: offset_start?: number;
}

export interface CorrectionResult {
  request_id: string;
  mode: string;
  model: string;
  chunks: CorrectionChunk[];
  total_cost_usd: number;
  final_text: string;
}

export interface CorrectionRequestPayload {
  text: string;
  mode: string;
  user_custom_prompt?: string;
  correction_csv?: string;
  model?: string;
}

export interface ApiErrorResponse {
  error?: string;
  detail?: string;
  // Allow additional fields without using 'any'
  [key: string]: unknown;
}

export type MaybeResult = CorrectionResult | null;
