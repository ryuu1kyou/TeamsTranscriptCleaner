import React, { useMemo, useState, useCallback } from 'react';
import { TokenEstimate } from '../components/TokenEstimate';
import { CorrectionRequestPayload } from '../types';

interface Props {
  onSubmit(payload: CorrectionRequestPayload): Promise<void> | void;
  disabled?: boolean;
  onTextChange?(v: string): void;
  initialText?: string;
  onMetaChange?(meta: { mode: string; model: string; prompt: string; csv: string }): void;
}

export const CorrectionForm: React.FC<Props> = ({
  onSubmit,
  disabled,
  onTextChange,
  initialText = '',
  onMetaChange,
}) => {
  // Keys
  const META_KEY = 'ttc_meta_v1';
  const defaultCsv = '誤,正';
  // Hydrate meta from localStorage if present
  const hydrateMeta = (): {
    mode: string;
    model: string;
    prompt: string;
    csv: string;
  } => {
    try {
      const raw = localStorage.getItem(META_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (
          parsed &&
          typeof parsed.mode === 'string' &&
          typeof parsed.model === 'string' &&
          typeof parsed.prompt === 'string' &&
          typeof parsed.csv === 'string'
        ) {
          return {
            mode: parsed.mode,
            model: parsed.model,
            prompt: parsed.prompt,
            csv: parsed.csv || defaultCsv,
          };
        }
      }
    } catch {}
    return { mode: 'misspelling', model: 'gpt-4o', prompt: '', csv: defaultCsv };
  };
  const initialMeta = hydrateMeta();
  const [mode, setMode] = useState(initialMeta.mode);
  const [model, setModel] = useState(initialMeta.model);
  const [prompt, setPrompt] = useState(initialMeta.prompt);
  const [csv, setCsv] = useState(initialMeta.csv);
  const [text, setText] = useState(initialText);
  const [validationError, setValidationError] = useState<string | null>(null);
  const [uploadError, setUploadError] = useState<string | null>(null);

  // Limits
  const MAX_TEXT_BYTES = 2 * 1024 * 1024; // 2MB
  const MAX_CSV_BYTES = 512 * 1024; // 512KB

  const validateCsv = useCallback(
    (content: string): string | null => {
      if (mode !== 'misspelling') return null;
      const trimmed = content.trim();
      if (!trimmed) return 'CSVが空です';
      const lines = trimmed.split(/\r?\n/);
      if (!lines.length) return 'CSV行がありません';
      const header = lines[0].split(',');
      if (header[0] !== '誤' || header[1] !== '正')
        return 'ヘッダーは『誤,正』で始まる必要があります';
      if (lines.length < 2) return 'データ行がありません';
      for (let i = 1; i < lines.length; i++) {
        const cols = lines[i].split(',');
        if (cols.length < 2 || !cols[0].trim() || !cols[1].trim()) {
          return `${i + 1}行目が不正 (空欄または列不足)`;
        }
      }
      return null;
    },
    [mode]
  );

  const disableRun = useMemo(() => {
    if (!text.trim()) return true;
    if (uploadError) return true;
    if (mode === 'misspelling') {
      const err = validateCsv(csv);
      setValidationError(err);
      if (err) return true;
    }
    return false;
  }, [text, mode, csv, validateCsv, uploadError]);

  const readFileAsText = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onerror = () => reject(new Error('ファイル読み込み失敗'));
      reader.onload = () => resolve(String(reader.result || ''));
      reader.readAsText(file);
    });
  };

  const handleTextFile = async (f: File) => {
    setUploadError(null);
    if (f.size > MAX_TEXT_BYTES) {
      setUploadError(
        `テキストファイルが大きすぎます (最大 ${(MAX_TEXT_BYTES / 1024 / 1024).toFixed(1)}MB)`
      );
      return;
    }
    try {
      const content = await readFileAsText(f);
      // Normalize newlines
      const normalized = content.replace(/\r\n?/g, '\n');
      setText(normalized);
      onTextChange?.(normalized);
    } catch (e) {
      setUploadError(e instanceof Error ? e.message : String(e));
    }
  };

  const handleCsvFile = async (f: File) => {
    setUploadError(null);
    if (f.size > MAX_CSV_BYTES) {
      setUploadError(
        `CSVファイルが大きすぎます (最大 ${(MAX_CSV_BYTES / 1024).toFixed(0)}KB)`
      );
      return;
    }
    try {
      const content = await readFileAsText(f);
      const normalized = content.replace(/\r\n?/g, '\n');
      setCsv(normalized);
      updateMeta();
      const err = validateCsv(normalized);
      setValidationError(err);
    } catch (e) {
      setUploadError(e instanceof Error ? e.message : String(e));
    }
  };

  const handleRun = () => {
    if (disableRun) return;
    onSubmit({
      text,
      mode,
      user_custom_prompt: prompt,
      correction_csv: mode === 'misspelling' ? csv : undefined,
      model,
    });
  };

  const persistMeta = useCallback(
    (next: { mode: string; model: string; prompt: string; csv: string }) => {
      try {
        localStorage.setItem(META_KEY, JSON.stringify(next));
      } catch {}
      onMetaChange?.(next);
    },
    [onMetaChange]
  );

  const updateMeta = () => {
    persistMeta({ mode, model, prompt, csv });
  };

  return (
    <div className="form-panel">
      <h2>Input</h2>
      <div className="field">
        <label>Mode</label>
        <select
          value={mode}
          onChange={(e) => {
            setMode(e.target.value);
            setValidationError(null);
            updateMeta();
          }}
          disabled={disabled}
        >
          <option value="misspelling">misspelling</option>
          <option value="grammar">grammar</option>
          <option value="summarize">summarize</option>
        </select>
      </div>
      <div className="field">
        <label>Model</label>
        <input
          value={model}
          onChange={(e) => {
            setModel(e.target.value);
            updateMeta();
          }}
          disabled={disabled}
        />
      </div>
      <div className="field">
        <label>Custom Prompt</label>
        <textarea
          value={prompt}
          onChange={(e) => {
            setPrompt(e.target.value);
            updateMeta();
          }}
          rows={2}
          disabled={disabled}
        />
      </div>
      {mode === 'misspelling' && (
        <div className="field">
          <label>Correction CSV</label>
          <textarea
            value={csv}
            onChange={(e) => {
              setCsv(e.target.value);
              updateMeta();
            }}
            rows={4}
            disabled={disabled}
          />
          <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginTop: 4 }}>
            <label style={{ fontSize: '0.85rem' }}>
              <input
                type="file"
                accept=".csv,text/csv"
                style={{ display: 'none' }}
                disabled={disabled}
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) handleCsvFile(file);
                  e.target.value = '';
                }}
              />
              <span className="mini button-like">CSVアップロード</span>
            </label>
            <span style={{ fontSize: '0.7rem', opacity: 0.7 }}>
              最大{(MAX_CSV_BYTES / 1024).toFixed(0)}KB
            </span>
          </div>
          {validationError && (
            <div className="status error" style={{ marginTop: 4 }}>
              {validationError}
            </div>
          )}
        </div>
      )}
      <div className="field">
        <label>Transcript Text</label>
        <textarea
          value={text}
          onChange={(e) => {
            setText(e.target.value);
            onTextChange?.(e.target.value);
          }}
          rows={12}
          disabled={disabled}
        />
        <div style={{ display: 'flex', gap: '0.5rem', flexWrap: 'wrap', marginTop: 4 }}>
          <label style={{ fontSize: '0.85rem' }}>
            <input
              type="file"
              accept=".txt,text/plain"
              style={{ display: 'none' }}
              disabled={disabled}
              onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) handleTextFile(file);
                e.target.value = '';
              }}
            />
            <span className="mini button-like">TXTアップロード</span>
          </label>
          <span style={{ fontSize: '0.7rem', opacity: 0.7 }}>
            最大{(MAX_TEXT_BYTES / 1024 / 1024).toFixed(1)}MB
          </span>
        </div>
      </div>
      {uploadError && (
        <div className="status error" style={{ marginTop: 4 }}>
          {uploadError}
        </div>
      )}
      {/* Token / Cost Estimate */}
      <TokenEstimate text={text} mode={mode} model={model} prompt={prompt} csv={csv} />
      <div className="actions" style={{ marginTop: '0.5rem' }}>
        <button onClick={handleRun} disabled={disabled || disableRun}>
          Run
        </button>
        <button
          onClick={() => setText('')}
          type="button"
          className="secondary"
          disabled={disabled}
        >
          Clear
        </button>
      </div>
    </div>
  );
};
