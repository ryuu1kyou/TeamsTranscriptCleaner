import React from "react";
import { CorrectionChunk } from "../types";

interface ChunkTableProps {
  chunks: CorrectionChunk[];
  onJump(index: number): void;
}

export const ChunkTable: React.FC<ChunkTableProps> = ({ chunks, onJump }) => {
  if (!chunks?.length) return null;
  return (
    <div className="chunk-table-panel">
      <h3>Chunks</h3>
      <table className="chunk-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Tokens(est)</th>
            <th>Cost</th>
            <th>Preview</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          {chunks.map((c, i) => (
            <tr key={i}>
              <td>{c.chunk_index ?? i}</td>
              <td>{c.original_tokens_est ?? "-"}</td>
              <td>{c.cost_usd ?? "-"}</td>
              <td className="preview-cell">
                {String(c.corrected || "").slice(0, 50)}
              </td>
              <td>
                <button className="mini" onClick={() => onJump(i)}>
                  Jump
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};
