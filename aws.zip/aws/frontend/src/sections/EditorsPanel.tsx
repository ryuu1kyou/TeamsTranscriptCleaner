import React, { useEffect, useMemo, useState } from 'react';

interface EditorsPanelProps {
  original: string;
  corrected: string;
  onCorrectedChange(v: string): void;
}

// Simple char diff highlighter similar to Streamlit logic
function diffHtml(a: string, b: string): string {
  function normalize(t: string) {
    // Replace CRLF with LF and convert full-width spaces (U+3000) to normal spaces
    return t
      .replace(/\r\n?/g, '\n')
      .replace(/\u3000/g, ' ')
      .trim();
  }
  const na = normalize(a);
  const nb = normalize(b);
  const aLines = na.split('\n');
  const bLines = nb.split('\n');
  const max = Math.max(aLines.length, bLines.length);
  const out: string[] = [];
  for (let i = 0; i < max; i++) {
    const A = aLines[i] || '';
    const B = bLines[i] || '';
    out.push(lineDiff(A, B));
  }
  return out.join('<br>');
}

function lineDiff(a: string, b: string): string {
  // naive sequence diff
  const m = a.length,
    n = b.length;
  const dp: number[][] = Array.from({ length: m + 1 }, () => Array(n + 1).fill(0));
  for (let i = m - 1; i >= 0; i--) {
    for (let j = n - 1; j >= 0; j--) {
      dp[i][j] =
        a[i] === b[j] ? 1 + dp[i + 1][j + 1] : Math.max(dp[i + 1][j], dp[i][j + 1]);
    }
  }
  let i = 0,
    j = 0;
  const parts: string[] = [];
  while (i < m && j < n) {
    if (a[i] === b[j]) {
      parts.push(escapeHtml(a[i]));
      i++;
      j++;
    } else if (dp[i + 1][j] >= dp[i][j + 1]) {
      parts.push(`<span class="diff-del">${escapeHtml(a[i])}</span>`);
      i++;
    } else {
      parts.push(`<span class="diff-add">${escapeHtml(b[j])}</span>`);
      j++;
    }
  }
  while (i < m) {
    parts.push(`<span class="diff-del">${escapeHtml(a[i])}</span>`);
    i++;
  }
  while (j < n) {
    parts.push(`<span class="diff-add">${escapeHtml(b[j])}</span>`);
    j++;
  }
  return parts.join('');
}

function escapeHtml(s: string) {
  return s.replace(
    /[&<>"']/g,
    (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!
  );
}

export const EditorsPanel: React.FC<EditorsPanelProps> = ({
  original,
  corrected,
  onCorrectedChange,
}) => {
  const [showDiff, setShowDiff] = useState(false);
  const [localCorrected, setLocalCorrected] = useState(corrected);

  useEffect(() => {
    setLocalCorrected(corrected);
  }, [corrected]);

  const diff = useMemo(
    () => (showDiff ? diffHtml(original, localCorrected) : ''),
    [showDiff, original, localCorrected]
  );

  return (
    <div className="editors-wrap">
      <div className="editor-col">
        <h3>訂正前(編集不可)</h3>
        <textarea value={original} readOnly rows={20} />
      </div>
      <div className="editor-col">
        <h3>訂正後(手修正可)</h3>
        <textarea
          value={localCorrected}
          onChange={(e) => {
            setLocalCorrected(e.target.value);
            onCorrectedChange(e.target.value);
          }}
          rows={20}
        />
        <label className="diff-toggle">
          <input
            type="checkbox"
            checked={showDiff}
            onChange={(e) => setShowDiff(e.target.checked)}
          />{' '}
          差分表示
        </label>
        {showDiff && (
          <div className="diff-view" dangerouslySetInnerHTML={{ __html: diff }} />
        )}
      </div>
    </div>
  );
};
