import React, { useEffect, useMemo, useState } from "react";

interface Props {
  apiBase: string;
  onChange(v: string): void;
}

function normalizeUrl(raw: string): string {
  const t = raw.trim();
  if (!t) return "";
  // Add scheme if user omitted
  if (!/^https?:\/\//i.test(t)) return "https://" + t;
  return t;
}

function validateUrl(raw: string): string | null {
  const v = raw.trim();
  if (!v) return null; // empty is allowed (user can later fill)
  if (/\s/.test(v)) return "スペースを含めることはできません";
  const candidate = normalizeUrl(v);
  try {
    const u = new URL(candidate);
    if (!/^https?:$/.test(u.protocol)) return "http/https のみ対応";
    if (!u.hostname) return "ホスト名が不正です";
    return null;
  } catch (e) {
    return "URL 形式が不正です";
  }
}

export const ApiConfigBar: React.FC<Props> = ({ apiBase, onChange }) => {
  const [touched, setTouched] = useState(false);
  const [draft, setDraft] = useState(apiBase);
  const error = useMemo(() => validateUrl(draft), [draft]);

  useEffect(() => {
    setDraft(apiBase);
  }, [apiBase]);

  const commit = (val: string) => {
    const norm = normalizeUrl(val);
    onChange(norm);
    try {
      localStorage.setItem("ttc_api_base", norm);
    } catch {}
  };

  return (
    <div className="api-bar">
      <label style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        <span style={{ fontSize: ".65rem", letterSpacing: ".5px" }}>
          API Endpoint
        </span>
        <input
          value={draft}
          onChange={(e) => {
            setDraft(e.target.value);
            setTouched(true);
          }}
          onBlur={() => {
            if (!error && touched) commit(draft);
          }}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              if (!error) commit(draft);
            }
          }}
          placeholder="https://xxxx.execute-api.ap-northeast-1.amazonaws.com"
          className={error && touched ? "invalid" : ""}
        />
      </label>
      {error && touched && (
        <div className="status error" style={{ margin: 0 }}>
          {error}
        </div>
      )}
      {!error && touched && draft && (
        <div className="status ok" style={{ margin: 0 }}>
          OK
        </div>
      )}
    </div>
  );
};
