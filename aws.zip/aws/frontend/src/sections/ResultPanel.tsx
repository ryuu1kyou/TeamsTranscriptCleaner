import React from "react";
import { CorrectionResult } from "../types";

interface Props {
  loading: boolean;
  result: CorrectionResult | null;
  error: string | null;
}

export const ResultPanel: React.FC<Props> = ({ loading, result, error }) => {
  return (
    <div className="result-panel">
      <h2>Result</h2>
      {loading && <div className="status">Processing...</div>}
      {error && <div className="status error">{error}</div>}
      {result && (
        <>
          <div className="status ok">Done (Cost: {result.total_cost_usd})</div>
          <div className="meta">Request: {result.request_id}</div>
          <textarea value={result.final_text || ""} readOnly rows={12} />
          <details>
            <summary>Raw JSON</summary>
            <pre>{JSON.stringify(result, null, 2)}</pre>
          </details>
        </>
      )}
    </div>
  );
};
