// Runtime API endpoint configuration
// Unified naming: prefer window.__TTC_CONFIG.API_BASE
// (Backward compatibility: application code can still read legacy window.__TTC_API_BASE if present.)
window.__TTC_CONFIG = {
	API_BASE: "" // set to e.g. "https://xxxx.execute-api.ap-northeast-1.amazonaws.com" at deploy time
};
// Legacy fallback variable (optional). Remove later once code fully migrated.
window.__TTC_API_BASE = window.__TTC_CONFIG.API_BASE;
