import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Deployment note:
// When building for S3 static hosting, ensure all assets are relative.
// We set base:'./' so that index.html can be opened from the S3 website endpoint root.
// If you later put the app behind CloudFront with a root origin path you can keep this.
export default defineConfig({
  plugins: [react()],
  base: "./",
  build: {
    outDir: "dist",
    sourcemap: true,
    target: "es2019",
    emptyOutDir: true,
  },
});
