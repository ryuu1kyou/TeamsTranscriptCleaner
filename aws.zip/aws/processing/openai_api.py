# Lambda-local minimized openai_api (removes local cost persistence side-effects)
from typing import List, Dict, Tuple
from openai import OpenAI
from .token_manager import MODEL_PRICING

# Direct env var access
import os

def get_client():
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY not set")
    return OpenAI(api_key=api_key)

def correct_text(
    processing_mode: str,
    user_custom_prompt: str,
    input_text: str,
    correction_words: List[Dict[str, str]],
    model: str = "gpt-4o",
) -> Tuple[str, float]:
    client = get_client()
    messages = []
    system_content = ""

    if processing_mode == "misspelling":
        strict = (
            "あなたは誤字脱字訂正専用のAIです。変更は誤字脱字リストに限定し、それ以外は元の文を保持してください。"
        )
        if correction_words:
            strict += "\n以下のリストを適用:\n" + "".join(
                [f"{w['誤']}→{w['正']}\n" for w in correction_words]
            )
        if user_custom_prompt:
            strict += f"\nユーザー補足: {user_custom_prompt}"
        system_content = strict
    elif processing_mode == "grammar":
        grammar = (
            "あなたは日本語文章を自然で文法的に正しく整えるAIです。意味は保持し、不要な改変や要約を避けてください。"
        )
        if correction_words:
            grammar += "\n優先修正リスト:\n" + "".join(
                [f"{w['誤']}→{w['正']}\n" for w in correction_words]
            )
        if user_custom_prompt:
            grammar += f"\nユーザー補足: {user_custom_prompt}"
        system_content = grammar
    elif processing_mode == "summarize":
        summarize = (
            "あなたは要約AIです。主要点を簡潔に抽出し、冗長部分を省いてください。"
        )
        if user_custom_prompt:
            summarize += f"\n指定: {user_custom_prompt}"
        system_content = summarize
    else:
        system_content = "与えられた指示に従ってください。"

    messages.append({"role": "system", "content": system_content})
    messages.append({"role": "user", "content": input_text})

    if model not in MODEL_PRICING:
        model = "gpt-4o"

    response = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=0,
        top_p=1,
        presence_penalty=0,
        frequency_penalty=0,
    )

    corrected_text = response.choices[0].message.content
    total_tokens = response.usage.total_tokens
    price_per_1k = MODEL_PRICING.get(model, 0.01)
    cost = (total_tokens / 1000) * price_per_1k
    return corrected_text, cost
