# Minimal processing package copied for Lambda packaging
