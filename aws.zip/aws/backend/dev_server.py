"""Local development Flask server wrapping the Lambda handler.

Run:
  pip install -r backend/requirements.txt flask
  export OPENAI_API_KEY=sk-... (or setx on Windows)
  python aws\backend\dev_server.py

Endpoints:
  POST /correct
  GET  /corrections/<request_id>
  GET  /health
"""
from flask import Flask, request, Response
import json
from handler import lambda_handler

app = Flask(__name__)


def _invoke(path: str, method: str = "GET", body: str | None = None):
    event = {
        "rawPath": path,
        "requestContext": {"http": {"method": method}},
    }
    if body is not None:
        event["body"] = body
    return lambda_handler(event, None)


@app.get("/health")
def health():
    r = _invoke("/health", "GET")
    return Response(r["body"], status=r["statusCode"], mimetype="application/json")


@app.post("/correct")
def correct():
    r = _invoke("/correct", "POST", request.data.decode("utf-8"))
    return Response(r["body"], status=r["statusCode"], mimetype="application/json")


@app.get("/corrections/<rid>")
def get_corr(rid: str):
    r = _invoke(f"/corrections/{rid}", "GET")
    return Response(r["body"], status=r["statusCode"], mimetype="application/json")


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5001, debug=True)