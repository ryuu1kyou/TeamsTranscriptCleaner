"""DynamoDB persistence utilities for correction results.

Table key schema expected:
  - Partition key: request_id (String)
  - Sort key: chunk_index (Number)
"""
from __future__ import annotations
import os
import uuid
from datetime import datetime, timezone
from typing import List, Dict, Any, Optional

import boto3
from boto3.dynamodb.conditions import Key

_dynamo = None
_table = None


def _get_table():  # lazy init
    global _dynamo, _table
    if _table is not None:
        return _table
    table_name = os.getenv("CORRECTIONS_TABLE")
    if not table_name:
        return None
    if _dynamo is None:
        endpoint = os.getenv("DYNAMODB_ENDPOINT")  # e.g. http://localhost:8000 for local
        if endpoint:
            _dynamo = boto3.resource("dynamodb", endpoint_url=endpoint, region_name=os.getenv("AWS_REGION", "ap-northeast-1"))
        else:
            _dynamo = boto3.resource("dynamodb")
    _table = _dynamo.Table(table_name)
    return _table


def new_request_id() -> str:
    return uuid.uuid4().hex


def save_correction(
    request_id: str,
    mode: str,
    model: str,
    total_cost: float,
    chunks: List[Dict[str, Any]],
    total_input_length: int,
    total_output_length: int,
) -> bool:
    table = _get_table()
    if table is None:
        return False
    ts = datetime.now(timezone.utc).isoformat()
    total_chunks = len(chunks)
    try:
        with table.batch_writer(overwrite_by_pkeys=["request_id", "chunk_index"]) as batch:
            for c in chunks:
                batch.put_item(
                    Item={
                        "request_id": request_id,
                        "chunk_index": int(c.get("index", 0)),
                        "mode": mode,
                        "model": model,
                        "created_at": ts,
                        "cost": float(c.get("cost", 0.0)),
                        "original_length": int(c.get("original_length", 0)),
                        "corrected_length": int(c.get("corrected_length", 0)),
                        "total_cost": float(total_cost),
                        "chunk_text": (c.get("text", "") or "")[:3800],  # guard size
                        "total_chunks": total_chunks,
                        "summary": (c.get("text", "") or "")[:100].replace("\n", " "),
                    }
                )
        return True
    except Exception:
        return False


def load_correction(request_id: str) -> Optional[Dict[str, Any]]:
    table = _get_table()
    if table is None:
        return None
    try:
        resp = table.query(
            KeyConditionExpression=Key("request_id").eq(request_id),
        )
    except Exception:
        return None
    items = resp.get("Items", [])
    if not items:
        return None
    items.sort(key=lambda x: x.get("chunk_index", 0))
    merged_text = "\n\n".join(i.get("chunk_text", "") for i in items)
    first = items[0]
    return {
        "request_id": request_id,
        "mode": first.get("mode"),
        "model": first.get("model"),
        "total_cost": float(first.get("total_cost", 0.0)),
        "total_chunks": int(first.get("total_chunks", len(items))),
        "created_at": first.get("created_at"),
        "merged_text": merged_text,
        "chunks": [
            {
                "index": int(i.get("chunk_index", 0)),
                "summary": i.get("summary", ""),
                "original_length": int(i.get("original_length", 0)),
                "corrected_length": int(i.get("corrected_length", 0)),
                "cost": float(i.get("cost", 0.0)),
            }
            for i in items
        ],
    }
