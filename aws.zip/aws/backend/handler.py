import json
import os
import boto3
import logging
import sys
import base64
from uuid import uuid4
from datetime import datetime, timezone
from processing.openai_api import correct_text
from processing.token_manager import count_tokens, split_text_into_chunks, merge_corrected_chunks
from persistence import save_correction, new_request_id, load_correction

SSM_PARAM_NAME = os.getenv("OPENAI_PARAM_NAME", "/prod/openai/api_key")
_ssm = None
_cached_key = None

# Basic logger (Lambda default logger already configured; just ensure level)
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def _cors_headers():
    """Build CORS headers dynamically each invocation so env var updates take effect on warm containers."""
    allowed_origin = os.getenv("ALLOWED_ORIGIN", "*")
    return {
        "Access-Control-Allow-Origin": allowed_origin,
        "Access-Control-Allow-Headers": "Content-Type,Authorization",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Access-Control-Max-Age": "300"
    }


def get_openai_key():
    """Fetch and cache OpenAI API key from SSM Parameter Store (SecureString)."""
    global _ssm, _cached_key
    if _cached_key:
        return _cached_key
    # Local fallback: direct env var
    direct = os.getenv("OPENAI_API_KEY")
    if direct:
        _cached_key = direct
        return _cached_key
    if _ssm is None:
        _ssm = boto3.client("ssm")
    try:
        resp = _ssm.get_parameter(Name=SSM_PARAM_NAME, WithDecryption=True)
        _cached_key = resp["Parameter"]["Value"]
        return _cached_key
    except Exception:
        return None


def _resp(status: int, body: dict):
    # Merge fresh CORS headers each response
    headers = {
        "Content-Type": "application/json; charset=utf-8",
        "Cache-Control": "no-store",
        **_cors_headers(),
    }
    return {
        "statusCode": status,
        "headers": headers,
        "body": json.dumps(body, ensure_ascii=False)
    }


def lambda_handler(event, _context):  # pragma: no cover (AWS entry point)
    path = event.get("rawPath") or event.get("path") or ""
    method = event.get("requestContext", {}).get("http", {}).get("method") or event.get("httpMethod")

    # CORS preflight shortcut: ANY /{proxy+} ルートで OPTIONS も Lambda に到達するためここで即返却
    if method == "OPTIONS":
        return {"statusCode": 204, "headers": _cors_headers()}

    if path == "/health":
        return _resp(200, {"status": "ok", "time": datetime.now(timezone.utc).isoformat()})

    # Retrieval endpoint: /corrections/{request_id}
    if path.startswith("/corrections/") and method == "GET":
        request_id = path.split("/", 2)[2]
        data = load_correction(request_id)
        if not data:
            return _resp(404, {"error": "not_found", "request_id": request_id})
        return _resp(200, data)

    if path == "/correct" and method == "POST":
        # Unified body extraction (supports API Gateway HttpApi both plain & base64)
        body_is_base64 = event.get("isBase64Encoded")
        raw_body = event.get("body")
        if raw_body is None:
            return _resp(400, {"error": "empty_body", "message": "Request body is required."})
        if body_is_base64:
            try:
                raw_body = base64.b64decode(raw_body).decode("utf-8", errors="replace")
            except Exception as e:
                return _resp(400, {"error": "body_decode_failed", "message": f"Failed to base64 decode body: {e}"})
        try:
            data = json.loads(raw_body)
        except json.JSONDecodeError as je:
            # Attempt fallback: pseudo JSON like {text:foo,mode:bar}
            fallback = None
            rb_strip = raw_body.strip()
            if rb_strip.startswith('{') and rb_strip.endswith('}'):
                import re
                # Heuristic: add quotes around keys without quotes, then around bare string values (no digits/boolean/null)
                temp = rb_strip
                # Quote keys: {key: -> {"key":
                temp = re.sub(r'{\s*([A-Za-z0-9_\-]+)\s*:', r'{"\1":', temp)
                temp = re.sub(r',\s*([A-Za-z0-9_\-]+)\s*:', r',"\1":', temp)
                # Quote bare values that look like words with spaces or letters and aren't true/false/null/numbers
                def _quote_val(match):
                    val = match.group(1)
                    if val in ('true','false','null'):
                        return ':' + val
                    # number?
                    try:
                        float(val)
                        return ':' + val
                    except Exception:
                        return ':"' + val + '"'
                temp2 = re.sub(r':([A-Za-z][^,}\"]*)', _quote_val, temp)
                try:
                    fallback = json.loads(temp2)
                except Exception:
                    fallback = None
            if fallback is not None:
                data = fallback
            else:
                snippet = raw_body[:120]
                return _resp(400, {
                    "error": "invalid_json",
                    "message": f"JSON decode error: {je.msg}",
                    "position": {"lineno": je.lineno, "colno": je.colno},
                    "snippet": snippet
                })
        except Exception as e:
            return _resp(400, {"error": "invalid_json", "message": str(e)})

        text = data.get("text", "")
        mode = data.get("mode", "misspelling")
        custom_prompt = data.get("custom_prompt", "")
        csv_text = data.get("csv_text")  # reserved for future parsing
        if not text:
            return _resp(400, {"error": "text required"})

        # Simple mojibake / garbled detection (ASCII '?' ratio) - relaxed threshold 0.8
        if text:
            qm = text.count('?')
            if qm and (qm / max(1, len(text))) > 0.8:
                return _resp(400, {
                    "error": "garbled_input",
                    "message": "Input appears heavily corrupted (mojibake). Ensure UTF-8 when sending.",
                    "question_mark_ratio": round(qm / len(text), 3)
                })

        # Log a small sample for diagnostics (helps verify Unicode not lost inside Lambda)
        try:
            logger.info("/correct received text_sample='%s' len=%d mode=%s", text[:20], len(text), mode)
        except Exception:
            pass

        debug_unicode = os.getenv("DEBUG_UNICODE") == "1"
        debug_payload = {}
        if debug_unicode:
            # Capture code points and first 64 bytes of raw body for diagnostics
            raw_body = event.get("body") or ""
            try:
                raw_bytes = raw_body.encode("utf-8", errors="replace")
            except Exception:
                raw_bytes = b""
            debug_payload = {
                "codepoints": [ord(c) for c in text[:30]],
                "raw_body_prefix_b64": base64.b64encode(raw_bytes[:64]).decode("ascii"),
            }

        try:
            model_name = data.get("model", "gpt-4o")
            # Chunk parameters (env tunable + per-request override)
            max_tokens = int(data.get("chunk_token_limit") or os.getenv("CHUNK_TOKEN_LIMIT", "3500"))
            overlap_chars = int(data.get("chunk_overlap_chars") or os.getenv("CHUNK_OVERLAP_CHARS", "0"))
            est_tokens = count_tokens(text)
            chunk_results = []
            total_cost = 0.0
            if est_tokens > max_tokens:
                raw_chunks = split_text_into_chunks(text, max_tokens, overlap_chars)
                for idx, ch in enumerate(raw_chunks, 1):
                    part_corrected, part_cost = correct_text(mode, custom_prompt, ch, [], model_name)
                    chunk_results.append({
                        "index": idx,
                        "original_length": len(ch),
                        "corrected_length": len(part_corrected),
                        "cost": part_cost,
                        "text": part_corrected
                    })
                    total_cost += part_cost
                merged = merge_corrected_chunks([c["text"] for c in chunk_results], mode)
                corrected_text = merged
                cost = total_cost
                chunk_count = len(chunk_results)
            else:
                corrected_text, cost = correct_text(mode, custom_prompt, text, [], model_name)
                chunk_results = [{
                    "index": 1,
                    "original_length": len(text),
                    "corrected_length": len(corrected_text),
                    "cost": cost,
                    "text": corrected_text  # ensure persisted
                }]
                chunk_count = 1
            try:
                import openai as _ov
                openai_version = getattr(_ov, "__version__", None)
            except Exception:
                openai_version = None
            request_id = new_request_id()
            # Persist (best effort)
            try:
                save_correction(
                    request_id=request_id,
                    mode=mode,
                    model=model_name,
                    total_cost=cost,
                    chunks=[
                        {**c, "text": c.get("text", "")}
                        for c in chunk_results
                        if "text" in c or chunk_count == 1
                    ],
                    total_input_length=len(text),
                    total_output_length=len(corrected_text),
                )
            except Exception:
                logger.warning("DynamoDB save failed", exc_info=True)
            resp_body = {
                "corrected_text": corrected_text,
                "echo": text,
                "mode": mode,
                "openai_mode": os.getenv("USE_REAL_OPENAI"),
                "openai_version": openai_version,
                "chunk_count": chunk_count,
                "chunks": chunk_results,
                "total_cost": cost,
                "estimated_input_cost": cost,
                "request_id": request_id
            }
            if debug_payload:
                resp_body["debug_unicode"] = debug_payload
            return _resp(200, resp_body)
        except Exception as e:
            logger.exception("Processing failed")
            return _resp(500, {
                "error": "processing_failed",
                "detail": str(e),
                "openai_mode": os.getenv("USE_REAL_OPENAI"),
                "openai_version": openai_version if 'openai_version' in locals() else None
            })

    return _resp(404, {"error": "not found", "path": path})
