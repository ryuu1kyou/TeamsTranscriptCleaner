"""Real OpenAI integration with compatibility fallback.

Primary path: new SDK (>=1.x) using from openai import OpenAI
Fallback: legacy SDK (0.x) using import openai + openai.ChatCompletion.create
"""
from typing import List, Dict, Tuple
import os
import boto3
import logging
from .token_manager import MODEL_PRICING, count_tokens
import json
import urllib.request
import urllib.error

logger = logging.getLogger(__name__)

NEW_SDK = False
try:  # Attempt new style client
    from openai import OpenAI  # type: ignore
    NEW_SDK = True
except Exception:  # pragma: no cover
    OpenAI = None  # type: ignore
    import openai  # type: ignore

try:  # Obtain version for diagnostics
    import openai as _ov
    OPENAI_LIB_VERSION = getattr(_ov, "__version__", "unknown")
except Exception:  # pragma: no cover
    OPENAI_LIB_VERSION = "unavailable"

_client_cache = None
_cached_key = None
_ssm = None

OPENAI_PARAM_NAME = os.getenv("OPENAI_PARAM_NAME", "/prod/openai/api_key")


def _get_api_key() -> str:
    """Return OpenAI API key with precedence:
    1. OPENAI_API_KEY (direct env for local/dev or injected secret)
    2. TEST_OPENAI_API_KEY (optional test override)
    3. SSM Parameter (OPENAI_PARAM_NAME) – production path
    """
    global _cached_key, _ssm
    if _cached_key:
        return _cached_key
    # 1 & 2: direct environment fallbacks (avoid SSM call locally)
    direct = os.getenv("OPENAI_API_KEY") or os.getenv("TEST_OPENAI_API_KEY")
    if direct:
        _cached_key = direct
        return _cached_key
    # 3: SSM lookup (skip if explicitly disabled)
    if os.getenv("DISABLE_SSM") == "1":
        return ""  # caller will raise
    if _ssm is None:
        try:
            _ssm = boto3.client("ssm")
        except Exception:
            return ""
    try:
        resp = _ssm.get_parameter(Name=OPENAI_PARAM_NAME, WithDecryption=True)
        _cached_key = resp["Parameter"]["Value"]
        return _cached_key
    except Exception:
        return ""


def _get_client():  # return either OpenAI or legacy module; may return None if forced to raw HTTP
    global _client_cache
    if _client_cache:
        return _client_cache
    key = _get_api_key()
    if not key:
        raise ValueError("OpenAI API key not found in SSM Parameter Store")
    if NEW_SDK and OpenAI is not None:
        try:
            _client_cache = OpenAI(api_key=key)
        except TypeError as te:
            # Known mismatch (proxies arg). Fallback to legacy usage.
            logger.warning("OpenAI new client init TypeError (%s); falling back to legacy/raw", te)
            try:
                import openai  # type: ignore
                openai.api_key = key
                _client_cache = openai
            except Exception as inner:
                logger.error("Legacy import also failed (%s); will use raw HTTP fallback", inner)
                _client_cache = None
        except Exception as ex:
            logger.error("OpenAI client init failed (%s); using raw HTTP fallback", ex)
            _client_cache = None
    else:
        import openai  # type: ignore
        openai.api_key = key
        _client_cache = openai
    return _client_cache


def correct_text(
    processing_mode: str,
    user_custom_prompt: str,
    input_text: str,
    correction_words: List[Dict[str, str]],
    model: str = "gpt-4o",
) -> Tuple[str, float]:
    client = _get_client()

    system_content = ""
    if processing_mode == "misspelling":
        strict_system_prompt = (
            "あなたは誤字脱字訂正専用のAIです。絶対に要約、追加、削除、言い換え、書式変更、文体変更、内容の修正、段落の統合・分割、語順の変更、その他の編集は行わず、"
            "誤字脱字リストに基づく訂正のみを行ってください。誤字脱字リストに該当しない箇所は一切変更せず、元のテキストをそのまま残してください。"
            "訂正リストにない箇所は絶対に修正しないでください。人間による最終確認・修正が必須です。"
        )
        correction_instruction = ""
        if correction_words:
            correction_instruction = "以下の誤字脱字リストを優先的に適用してください：\n"
            for word in correction_words:
                correction_instruction += f"「{word['誤']}」→「{word['正']}」\n"
        system_content = f"{strict_system_prompt}\n\n{correction_instruction}".strip()
        if user_custom_prompt:
            system_content += f"\n\nユーザー補足: {user_custom_prompt}"
    elif processing_mode == "grammar":
        grammar_system_prompt = (
            "あなたは日本語の文章を自然で文法的に正しく校正するAIです。\n"
            "以下の指示に従って、提供されたテキストを修正してください。\n"
            "1. 文法的な誤りを修正します。\n"
            "2. 不自然な表現をより自然な日本語に修正します。\n"
            "3. 誤字脱字があれば修正します。"
        )
        if correction_words:
            grammar_system_prompt += "特に、以下のリストにある単語は優先的に修正してください：\n"
            for word in correction_words:
                grammar_system_prompt += f"「{word['誤']}」→「{word['正']}」\n"
        grammar_system_prompt += (
            "\n4. 元の文章の意味や主要な情報を保持し、勝手に内容を追加したり削除したりしないでください。\n"
            "5. 文体は元のテキストに合わせてください。"
        )
        system_content = grammar_system_prompt.strip()
        if user_custom_prompt:
            system_content += f"\n\nユーザー補足: {user_custom_prompt}"
    elif processing_mode == "summarize":
        summarize_system_prompt = (
            "あなたは提供された日本語のテキストを要約するAIです。\n"
            "以下の指示に従って、テキストの要点をまとめてください。\n"
            "1. テキスト全体の主要なトピックと結論を把握します。\n"
            "2. 重要な情報を抽出し、冗長な部分や詳細は省略します。\n"
            "3. 元のテキストの意図を正確に反映した要約を作成します。"
        )
        system_content = summarize_system_prompt.strip()
        if user_custom_prompt:
            system_content += f"\n\nユーザーからの具体的な指示: {user_custom_prompt}"
    else:
        system_content = "あなたはテキスト処理AIです。ユーザーの指示に従ってください。"
        if user_custom_prompt:
            system_content += f"\n\nユーザー指示: {user_custom_prompt}"

    messages = [
        {"role": "system", "content": system_content},
        {"role": "user", "content": input_text},
    ]

    if model not in MODEL_PRICING:
        model = "gpt-4o"

    # Call depending on SDK style
    try:
        if client is not None:
            if NEW_SDK and hasattr(client, "chat"):
                response = client.chat.completions.create(
                    model=model,
                    messages=messages,
                    temperature=0,
                    top_p=1,
                    presence_penalty=0,
                    frequency_penalty=0,
                )
                corrected_text = response.choices[0].message.content
                total_tokens = response.usage.total_tokens
            elif hasattr(client, "ChatCompletion"):
                response = client.ChatCompletion.create(
                    model=model,
                    messages=messages,
                    temperature=0,
                    top_p=1,
                    presence_penalty=0,
                    frequency_penalty=0,
                )
                corrected_text = response["choices"][0]["message"]["content"]
                total_tokens = response.get("usage", {}).get("total_tokens", 0)
            else:
                raise RuntimeError("Unsupported OpenAI client object; proceeding to raw HTTP fallback")
        else:
            raise RuntimeError("No OpenAI client – forcing raw HTTP fallback")
    except Exception as api_err:
        logger.warning("OpenAI SDK path failed (%s); using raw HTTP fallback", api_err)
        # Raw HTTP fallback
        key = _get_api_key()
        endpoint = "https://api.openai.com/v1/chat/completions"
        payload = {
            "model": model,
            "messages": messages,
            "temperature": 0,
            "top_p": 1,
            "presence_penalty": 0,
            "frequency_penalty": 0,
        }
        req = urllib.request.Request(endpoint, method="POST")
        body_bytes = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        req.add_header("Content-Type", "application/json; charset=utf-8")
        req.add_header("Authorization", f"Bearer {key}")
        try:
            with urllib.request.urlopen(req, body_bytes, timeout=30) as resp:  # nosec B310
                raw = resp.read().decode("utf-8", errors="replace")
                data = json.loads(raw)
        except urllib.error.HTTPError as he:
            err_txt = he.read().decode("utf-8", errors="replace")
            logger.error("Raw HTTP OpenAI error status=%s body=%s", he.code, err_txt)
            raise RuntimeError(f"raw_http_error status={he.code} body={err_txt[:200]}")
        corrected_text = data.get("choices", [{}])[0].get("message", {}).get("content", "")
        usage = data.get("usage", {})
        total_tokens = usage.get("total_tokens")
        if total_tokens is None:
            # approximate if usage not returned
            total_tokens = count_tokens(json.dumps(messages, ensure_ascii=False) + corrected_text)

    price_per_1k = MODEL_PRICING.get(model, 0.01)
    cost = (total_tokens / 1000) * price_per_1k
    return corrected_text, cost

def get_openai_version() -> str:
    return OPENAI_LIB_VERSION
