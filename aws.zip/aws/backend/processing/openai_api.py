"""Facade that switches between mock and real OpenAI based on env flag.

Set USE_REAL_OPENAI=1 in Lambda (or locally) to enable real API calls.
"""
import os
from typing import List, Dict, Tuple
from .token_manager import MODEL_PRICING, count_tokens

USE_REAL = os.getenv("USE_REAL_OPENAI") == "1"

if USE_REAL:
    from .openai_real import correct_text  # noqa: F401
else:
    def correct_text(processing_mode: str, user_custom_prompt: str, input_text: str,
                     correction_words: List[Dict[str, str]], model: str = "gpt-4o") -> Tuple[str, float]:
        prefix = {
            "misspelling": "[MISSPELLING]",
            "grammar": "[GRAMMAR]",
            "summarize": "[SUMMARY]",
        }.get(processing_mode, "[MODE]")
        est_tokens = count_tokens(input_text)
        price_per_1k = MODEL_PRICING.get(model, 0.01)
        cost = (est_tokens / 1000.0) * price_per_1k
        return f"{prefix} {input_text[:200]}...", cost

