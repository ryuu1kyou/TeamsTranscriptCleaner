from typing import Dict, List
import re

MODEL_PRICING: Dict[str, float] = {
    "gpt-4o": 0.02,  # simplified placeholder
    "gpt-3.5-turbo": 0.002,
}

def count_tokens(text: str) -> int:
    # Rough estimate
    return max(1, int(len(text) / 2))


def split_text_into_chunks(text: str, max_tokens: int, overlap_chars: int = 0) -> List[str]:
    """Split text into approximate token-limited chunks.

    Strategy:
    1. Split by double newline (logical paragraphs)
    2. If paragraph too large, split by sentence end punctuation
    3. If still too large, hard cut by character length derived from token heuristic
    4. Optional character overlap to preserve context between chunks
    """
    if not text:
        return [""]

    char_per_token = 2  # heuristic inverse of count_tokens
    max_chars = max_tokens * char_per_token

    paragraphs = text.split("\n\n")
    chunks: List[str] = []
    current: List[str] = []
    cur_len = 0

    def flush():
        nonlocal current, cur_len
        if current:
            chunk_text = "\n\n".join(current).strip()
            if chunk_text:
                chunks.append(chunk_text)
        current = []
        cur_len = 0

    for para in paragraphs:
        p_len = len(para)
        if p_len > max_chars:
            # sentence-level
            sentences = re.split(r'(?<=[。．！？!?])', para)
            for sent in sentences:
                if not sent:
                    continue
                if len(sent) > max_chars:
                    # hard cut
                    for i in range(0, len(sent), max_chars):
                        piece = sent[i:i+max_chars]
                        if cur_len + len(piece) > max_chars:
                            flush()
                        current.append(piece)
                        cur_len += len(piece)
                        flush()
                else:
                    if cur_len + len(sent) > max_chars:
                        flush()
                    current.append(sent)
                    cur_len += len(sent)
            flush()
        else:
            if cur_len + p_len > max_chars:
                flush()
            current.append(para)
            cur_len += p_len
    flush()

    # Apply overlap if requested (simple char-based append of trailing slice)
    if overlap_chars > 0 and len(chunks) > 1:
        overlapped: List[str] = []
        for i, ch in enumerate(chunks):
            if i == 0:
                overlapped.append(ch)
            else:
                prev_tail = chunks[i-1][-overlap_chars:]
                overlapped.append(prev_tail + ch)
        chunks = overlapped

    return chunks


def merge_corrected_chunks(chunks: List[str], mode: str) -> str:
    """Merge corrected chunk outputs.

    For grammar/misspelling we simply join with a double newline to avoid
    accidental sentence fusion. For summary we join then allow future
    post pass (not implemented here) to re-summarize if desired.
    """
    sep = "\n\n" if mode in ("grammar", "misspelling") else "\n"
    return sep.join(c.strip() for c in chunks if c.strip())
