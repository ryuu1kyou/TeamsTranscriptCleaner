from typing import List, Dict
import csv, io

def parse_csv_text(csv_text: str) -> List[Dict[str, str]]:
    result: List[Dict[str, str]] = []
    try:
        csv_file = io.StringIO(csv_text)
        reader = csv.reader(csv_file)
        _ = next(reader, None)
        for row in reader:
            if len(row) >= 2:
                result.append({"誤": row[0], "正": row[1]})
    except Exception as e:
        print(f"CSV parse error: {e}")
        return []
    return result