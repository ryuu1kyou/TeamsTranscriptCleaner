from typing import List, Dict
import re

MODEL_PRICING = {
    "gpt-4-1106-preview": 0.01,
    "gpt-4-0125-preview": 0.01,
    "gpt-4-1106-vision-preview": 0.01,
    "gpt-4-turbo": 0.01,
    "gpt-4o": 0.01,
    "gpt-4o-mini": 0.005,
    "gpt-4": 0.03,
    "gpt-3.5-turbo": 0.0015,
}

MODEL_MAX_TOKENS = {
    "gpt-4-1106-preview": 128000,
    "gpt-4-0125-preview": 128000,
    "gpt-4-1106-vision-preview": 128000,
    "gpt-4-turbo": 128000,
    "gpt-4o": 128000,
    "gpt-4o-mini": 128000,
    "gpt-4": 8192,
    "gpt-3.5-turbo": 4096,
}

def count_tokens(text: str) -> int:
    return len(text) // 4

def split_text(text: str, max_tokens: int = 4000) -> List[str]:
    paragraphs = text.split("\n\n")
    chunks: List[str] = []
    current_chunk: List[str] = []
    current_token_count = 0
    for paragraph in paragraphs:
        pt = count_tokens(paragraph)
        if pt > max_tokens:
            sentences = re.split(r"(?<=[。．！？])", paragraph)
            for sentence in sentences:
                if not sentence:
                    continue
                st = count_tokens(sentence)
                if current_token_count + st > max_tokens:
                    if current_chunk:
                        chunks.append("\n\n".join(current_chunk))
                        current_chunk = []
                        current_token_count = 0
                if st > max_tokens:
                    chars_per_token = 4
                    max_chars = max_tokens * chars_per_token
                    for i in range(0, len(sentence), max_chars):
                        chunks.append(sentence[i:i+max_chars])
                else:
                    current_chunk.append(sentence)
                    current_token_count += st
        else:
            if current_token_count + pt > max_tokens:
                if current_chunk:
                    chunks.append("\n\n".join(current_chunk))
                    current_chunk = []
                    current_token_count = 0
            current_chunk.append(paragraph)
            current_token_count += pt
    if current_chunk:
        chunks.append("\n\n".join(current_chunk))
    return chunks

def estimate_cost(text: str, model: str) -> Dict[str, float]:
    tokens = count_tokens(text)
    price_per_1k = MODEL_PRICING.get(model, 0.01)
    return {"tokens": tokens, "cost_usd": (tokens / 1000) * price_per_1k}

def get_max_tokens_for_model(model: str) -> int:
    return MODEL_MAX_TOKENS.get(model, 4000)