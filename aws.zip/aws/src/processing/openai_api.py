from typing import List, Dict, Tuple
from openai import OpenAI
from .token_manager import MODEL_PRICING
import os

def get_client():
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        raise ValueError("OPENAI_API_KEY not set")
    return OpenAI(api_key=key)

def correct_text(
    processing_mode: str,
    user_custom_prompt: str,
    input_text: str,
    correction_words: List[Dict[str, str]],
    model: str = "gpt-4o",
) -> Tuple[str, float]:
    client = get_client()
    messages = []
    sys = ""
    if processing_mode == "misspelling":
        sys = "誤字脱字のみ訂正し他は変更しない。"
        if correction_words:
            sys += "\nリスト:\n" + "".join([f"{w['誤']}→{w['正']}\n" for w in correction_words])
        if user_custom_prompt:
            sys += f"\n補足: {user_custom_prompt}"
    elif processing_mode == "grammar":
        sys = "文法・不自然表現を自然に修正。意味は保持。"
    elif processing_mode == "summarize":
        sys = "要点を簡潔に要約。"
    else:
        sys = "指示に従ってください。"
    messages.append({"role": "system", "content": sys})
    messages.append({"role": "user", "content": input_text})
    if model not in MODEL_PRICING:
        model = "gpt-4o"
    resp = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=0,
    )
    text = resp.choices[0].message.content
    total_tokens = resp.usage.total_tokens
    cost = (total_tokens / 1000) * MODEL_PRICING.get(model, 0.01)
    return text, cost