from __future__ import annotations
import json, os, uuid, base64
from typing import Any, Dict, List
from decimal import Decimal

from processing.openai_api import correct_text
from processing.csv_parser import parse_csv_text
from processing.token_manager import split_text, get_max_tokens_for_model, estimate_cost

# Diagnostic: log critical dependency versions once per cold start
try:  # pragma: no cover
    import pkg_resources, sys
    _deps = {d.project_name.lower(): d.version for d in pkg_resources.working_set
             if d.project_name.lower() in {"openai", "httpx", "anyio", "pydantic"}}
    print("LOADED_DEPENDENCIES", _deps, file=sys.stdout)
except Exception:  # pragma: no cover
    pass

try:
    import boto3  # type: ignore
except Exception:
    boto3 = None  # type: ignore

_dynamodb = None
if boto3:
    try:
        _dynamodb = boto3.resource("dynamodb")
    except Exception:
        _dynamodb = None

_ssm_client = None
_cached_api_key: str | None = None

def _ensure_api_key():
    global _ssm_client, _cached_api_key
    if os.getenv("OPENAI_API_KEY"):
        return
    if _cached_api_key:
        os.environ["OPENAI_API_KEY"] = _cached_api_key
        return
    if not boto3:
        raise RuntimeError("OPENAI_API_KEY not set and boto3 unavailable for SSM fetch")
    if _ssm_client is None:
        _ssm_client = boto3.client("ssm")  # type: ignore
    raw_names = os.getenv("OPENAI_PARAM_NAME")
    if raw_names:
        parts = [p.strip() for chunk in raw_names.replace(";", ",").split(",") for p in chunk.split() if p.strip()]
        candidates = parts or [raw_names.strip()]
    else:
        candidates = [
            "/prod/openai/api_key",
            "/openai/api_key",
            "/prod/OPENAI_API_KEY",
            "/openai/OPENAI_API_KEY",
        ]
    errors: List[str] = []
    for name in candidates:
        try:
            value = _ssm_client.get_parameter(Name=name, WithDecryption=True)["Parameter"]["Value"]  # type: ignore
        except Exception as e:
            errors.append(f"{name}: {e}")
            continue
        _cached_api_key = value
        os.environ["OPENAI_API_KEY"] = value
        return
    raise RuntimeError("Failed to resolve OpenAI key. Tried: " + ", ".join(candidates) + " Errors: " + " | ".join(errors))

def _get_table():
    name = os.getenv("CORRECTIONS_TABLE")
    if name and _dynamodb:
        return _dynamodb.Table(name)
    return None

SUPPORTED_MODES = {"misspelling", "grammar", "summarize"}

def _response(status: int, body: Dict[str, Any]):
    return {"statusCode": status, "headers": {"Content-Type": "application/json"}, "body": json.dumps(body, ensure_ascii=False)}

def lambda_handler(event, context):  # type: ignore
    try:
        _ensure_api_key()
    except Exception as e:
        return _response(500, {"error": "API key resolution failed", "detail": str(e)})

    if isinstance(event, dict) and "requestContext" in event and "body" in event:
        body_raw = event.get("body", "")
        if event.get("isBase64Encoded"):
            try:
                body_raw = base64.b64decode(body_raw).decode("utf-8")
            except Exception:
                return _response(400, {"error": "Invalid base64 body"})
        try:
            payload = json.loads(body_raw or "{}")
        except json.JSONDecodeError:
            return _response(400, {"error": "Body must be valid JSON"})
    else:
        payload = event if isinstance(event, dict) else {}

    text = payload.get("text") or payload.get("input_text")
    mode = payload.get("mode", "misspelling")
    user_prompt = payload.get("user_custom_prompt", "")
    correction_csv = payload.get("correction_csv", "")
    model = payload.get("model") or os.getenv("DEFAULT_MODEL", "gpt-4o")

    if not text:
        return _response(400, {"error": "'text' is required"})
    if mode not in SUPPORTED_MODES:
        return _response(400, {"error": f"Unsupported mode '{mode}'"})

    corrections = []
    if correction_csv:
        corrections = parse_csv_text(correction_csv)

    max_model_tokens = get_max_tokens_for_model(model)
    per_chunk_limit = int(max_model_tokens * 0.4)
    chunks = split_text(text, max_tokens=per_chunk_limit)

    request_id = str(uuid.uuid4())
    results: List[Dict[str, Any]] = []
    aggregate_cost = 0.0
    combined_output_parts: List[str] = []

    for idx, chunk in enumerate(chunks):
        try:
            corrected, cost = correct_text(
                processing_mode=mode,
                user_custom_prompt=user_prompt,
                input_text=chunk,
                correction_words=corrections,
                model=model,
            )
        except Exception as e:
            return _response(500, {"error": f"Model invocation failed at chunk {idx}", "detail": str(e)})
        aggregate_cost += cost
        combined_output_parts.append(corrected)
        results.append({
            "chunk_index": idx,
            "original_tokens_est": estimate_cost(chunk, model)["tokens"],
            "corrected": corrected,
            "cost_usd": round(cost, 6)
        })

    final_text = "\n\n".join(combined_output_parts)

    table = _get_table()
    if table:
        # DynamoDB does not accept Python float types; convert to Decimal.
        with table.batch_writer(overwrite_by_pkeys=["request_id", "chunk_index"]) as batch:  # type: ignore
            for r in results:
                cost_decimal = Decimal(str(r["cost_usd"]))  # ensure exact string conversion
                batch.put_item(Item={
                    "request_id": request_id,
                    "chunk_index": r["chunk_index"],
                    "mode": mode,
                    "model": model,
                    "cost_usd": cost_decimal,
                    "original_tokens_est": r["original_tokens_est"],
                    "timestamp": context.aws_request_id if context else "local",
                })

    return _response(200, {
        "request_id": request_id,
        "mode": mode,
        "model": model,
        "chunks": results,
        "total_cost_usd": round(aggregate_cost, 6),
        "final_text": final_text,
    })