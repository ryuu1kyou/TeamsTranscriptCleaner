# AWS Deployment & Operations Guide (TeamsTranscriptCleaner)

このドキュメントは **AWS 側 (aws/ ディレクトリ)** に限定した実装・運用方法をまとめたものです。将来このフォルダを独立リポジトリ化しても自立するように記述しています。ルートの README は更新せず、AWS 向け手順は本ファイルを参照してください。

---

## 1. 現行アーキテクチャ

```
Browser (React build on S3)
  │  GET index.html / assets / config.js
  ▼
S3 Static Website (teams-transcript-cleaner-frontend-<ACCOUNT>-ap-northeast-1)
  │  fetch POST /correct, GET /corrections/{id}, OPTIONS
  ▼
API Gateway HTTP API  (ANY /{proxy+})
  ▼
Lambda (backend/handler.py)
   ├ OpenAI API (校正・要約)
   ├ DynamoDB (corrections table)
   └ SSM Parameter Store (OpenAI SecureString)
```

将来追加予定: CloudFront + OAC, Cognito 認証, 監査ログ, レート制限。

### 主な特徴

- ランタイム API エンドポイントは `public/config.js` 経由で注入 (ビルド不要変更)
- CORS: API Gateway の自動 CORS 無効 → Lambda で `ALLOWED_ORIGIN` を動的付与
- デプロイは SAM (`template.yaml`) + S3 静的コンテンツ同期
- DynamoDB に校正結果チャンク保存 (再取得 API 用)

---

## 2. ディレクトリ構成 (aws/)

```
aws/
├── backend/                # Lambda コード (handler.py, processing/ など)
├── frontend/               # React/Vite プロジェクト (npm run build → dist/)
├── template.yaml           # SAM テンプレート
├── samconfig.toml          # SAM デプロイ設定 (profile / parameter_overrides)
├── local-env.json          # sam local 用環境変数 (任意)
├── events/                 # ローカルテストイベント
├── RUNBOOK.md              # 運用 Runbook (任意拡張)
└── README.md               # 本書
```

---

## 3. パラメータ & 環境変数

| 名称                   | 種別                         | 例 / 説明                                                                                                   |
| ---------------------- | ---------------------------- | ----------------------------------------------------------------------------------------------------------- |
| `/prod/openai/api_key` | SSM SecureString             | OpenAI API キー (KMS 既定)                                                                                  |
| `OpenAIParamName`      | SAM Parameter                | `/prod/openai/api_key`                                                                                      |
| `FrontendOrigin`       | SAM Parameter                | `http://teams-transcript-cleaner-frontend-<ACCOUNT>-ap-northeast-1.s3-website-ap-northeast-1.amazonaws.com` |
| `ALLOWED_ORIGIN`       | Lambda Env (template で参照) | 上記と同じ (動的 CORS)                                                                                      |
| `CHUNK_TOKEN_LIMIT`    | Lambda Env                   | 3500 (チャンク分割閾値)                                                                                     |
| `CHUNK_OVERLAP_CHARS`  | Lambda Env                   | 40 (再結合用重複)                                                                                           |
| `USE_REAL_OPENAI`      | Lambda Env                   | 1 (将来モック切替用)                                                                                        |

更新手順 (例: Origin 差し替え)

1. `samconfig.toml` の `parameter_overrides` を編集
2. `sam build && sam deploy`

---

## 4. 初回セットアップ (一度のみ)

```powershell
aws ssm put-parameter --name /prod/openai/api_key --type SecureString --value <OPENAI_KEY> --overwrite --region ap-northeast-1 --profile sso-admin
```

```powershell
cd aws
sam build --profile sso-admin
sam deploy --guided --profile sso-admin  # 以後 samconfig.toml に保存
```

SAM 出力 (Outputs) で `ApiEndpoint`, `FrontendBucketName`, `FrontendWebsiteURL` を控える。

---

## 5. フロントエンド ビルド & 配置

```powershell
cd aws/frontend
npm install
npm run build
aws s3 sync dist/ s3://<FrontendBucketName>/ --delete --profile sso-admin
# ランタイム設定
aws s3 cp public/config.js s3://<FrontendBucketName>/config.js --profile sso-admin
```

`public/config.js` 例:

```js
window.__TTC_CONFIG = {
  API_BASE: "https://<api-id>.execute-api.ap-northeast-1.amazonaws.com",
};
```

後で API を差し替える場合は `config.js` のみ更新すれば OK (再ビルド不要)。

---

## 6. CORS 戦略

| レイヤ      | 方式                                                     |
| ----------- | -------------------------------------------------------- |
| API Gateway | 自動 CORS 無効 (テンプレートから除去)                    |
| Lambda      | `_cors_headers()` が毎回 `ALLOWED_ORIGIN` を再評価し付与 |
| 変更手順    | Lambda 環境変数更新 → 次回呼出しで即反映                 |

OPTIONS は Lambda が 204 即時応答 (`Access-Control-Allow-*`)。

テスト (PowerShell):

```powershell
$ApiBase="https://<api-id>.execute-api.ap-northeast-1.amazonaws.com"; $Origin="http://teams-transcript-cleaner-frontend-<ACCOUNT>-ap-northeast-1.s3-website-ap-northeast-1.amazonaws.com"; (Invoke-WebRequest -Method Options -Uri "$ApiBase/correct" -Headers @{Origin=$Origin;'Access-Control-Request-Method'='POST';'Access-Control-Request-Headers'='content-type'}).Headers['access-control-allow-origin']
```

---

## 7. API 仕様 (現行)

### POST `/correct`

入力:

```json
{
  "text": "校正対象",
  "mode": "grammar",
  "custom_prompt": "(任意)",
  "chunk_token_limit": 3500
}
```

出力 (例):

```json
{
  "corrected_text": "...",
  "echo": "...",
  "mode": "grammar",
  "chunk_count": 1,
  "chunks": [{ "index": 1, "cost": 0.0032, "text": "..." }],
  "total_cost": 0.0032,
  "request_id": "<uuid>"
}
```

### GET `/corrections/{request_id}`

保存済みチャンクの再取得。存在しなければ 404。

### GET `/health`

`{"status":"ok"}`

### OPTIONS (任意パス)

204 + CORS ヘッダ。

---

## 8. ローカル開発フロー

| 目的               | コマンド                                                      |
| ------------------ | ------------------------------------------------------------- |
| Lambda ローカル    | `sam local start-api --env-vars local-env.json`               |
| React Dev          | `cd aws/frontend; npm run dev` (Vite `http://localhost:5173`) |
| エンドポイント設定 | ブラウザ UI の入力欄 or `public/config.js` 一時書換           |

### local-env.json 例

```json
{
  "CleanerFunction": {
    "OPENAI_PARAM_NAME": "/prod/openai/api_key",
    "USE_REAL_OPENAI": "1",
    "CHUNK_TOKEN_LIMIT": "3500",
    "CHUNK_OVERLAP_CHARS": "40"
  }
}
```

---

## 9. デプロイ更新フロー (差分)

| シナリオ               | 手順                             |
| ---------------------- | -------------------------------- |
| Lambda コード変更      | `sam build; sam deploy`          |
| CORS Origin 変更       | `samconfig.toml` 編集 → 上と同じ |
| API エンドポイント切替 | `config.js` 差し替え (S3 上書き) |
| フロント更新           | `npm run build` → `s3 sync`      |

---

## 10. DynamoDB 利用概要

| 項目     | 説明                                                               |
| -------- | ------------------------------------------------------------------ |
| テーブル | `teams-transcript-cleaner-corrections` (スタック名 + サフィックス) |
| 主キー   | `request_id` (HASH) + `chunk_index` (RANGE)                        |
| 保存内容 | 各チャンクの校正結果、コスト、長さ                                 |
| 再構築   | 取得時にマージ (単純連結 + オーバーラップ調整)                     |

---

## 11. コスト計測 (概要)

OpenAI 呼出時に推定トークン数ベースで概算コスト算出 (モデル単価はコード内定義)。正確な課金との差異が問題化した場合は OpenAI Usage API / ログ集計導入を検討。

---

## 12. トラブルシュート

| 症状                                        | 原因候補                       | 対処                                           |
| ------------------------------------------- | ------------------------------ | ---------------------------------------------- |
| OPTIONS 204 だが POST CORS 失敗             | `Origin` 不一致                | ブラウザ送信ヘッダ / `FrontendOrigin` を確認   |
| `access-control-allow-origin` が `*` のまま | 旧デプロイコンテナ             | Lambda コード更新で強制再ロード                |
| `garbled_input` エラー                      | 文字化け (`?` 多)              | UTF-8 送信 / エディタエンコード確認            |
| OpenAI Key 取得失敗                         | SSM 名 or IAM 権限             | `ssm:GetParameter` ポリシー / 名前綴りを再確認 |
| DynamoDB 保存失敗                           | IAM / テーブル名相違           | CloudWatch ログ & テーブル ARN 参照            |
| 高レイテンシ                                | OpenAI 待ち / コールドスタート | メモリ上げ / チャンク分割 / ウォームアップ     |

---

## 13. セキュリティ & 運用チェックリスト

- [ ] SSM Parameter: KMS 既定キー利用 / Plaintext 不使用
- [ ] Lambda IAM: 必要最小 (ssm:GetParameter, dynamodb:PutItem/Query)\*
- [ ] S3 Public: 将来 CloudFront + OAC 化で PublicGet 削除
- [ ] CORS: 特定オリジン固定 (ワイルドカード排除済)
- [ ] Logs: 機密文字列出力禁止 (OpenAI Key 未出力)
- [ ] Alarms: Lambda Errors / Throttles / Duration p95
- [ ] Budgets: 月次閾値通知設定

---

## 14. 今後の拡張候補

| 分類             | 内容                                           |
| ---------------- | ---------------------------------------------- |
| 配信             | CloudFront + OAC + Brotli + キャッシュポリシー |
| 認証             | Cognito / IAM Identity Center + 認可ロール     |
| 監査             | CloudTrail Lake + 構造化応答ログ (JSON)        |
| 最適化           | OpenAI リトライ / バックオフ / 部分差分再校正  |
| 複数オリジン     | `ALLOWED_ORIGIN` をカンマ分割 → 動的マッチ     |
| Usage メトリクス | コスト/文字数を CloudWatch EMF 送信            |

---

## 15. 移行 (独立リポジトリ化) メモ

1. この `aws/` を新リポジトリ root へコピー
2. ルートに `LICENSE`, `.github/workflows/deploy.yml` 追加
3. ローカル参照相対パス (上位階層) が無いことを確認
4. GitHub Actions (OpenID Connect → IAM ロール) で `sam deploy` 自動化

---

## 16. コマンドクイックリファレンス

```powershell
# 初回 or コード変更
sam build --profile sso-admin; sam deploy --profile sso-admin

# フロント更新
cd frontend; npm run build; aws s3 sync dist/ s3://<FrontendBucketName>/ --delete --profile sso-admin

# CORS / Origin 変更
# samconfig.toml 編集後:
sam deploy --profile sso-admin

# OPTIONS テスト
$ApiBase="https://<api-id>.execute-api.ap-northeast-1.amazonaws.com"; $Origin="http://teams-transcript-cleaner-frontend-<ACCOUNT>-ap-northeast-1.s3-website-ap-northeast-1.amazonaws.com"; (Invoke-WebRequest -Method Options -Uri "$ApiBase/correct" -Headers @{Origin=$Origin;'Access-Control-Request-Method'='POST';'Access-Control-Request-Headers'='content-type'}).StatusCode
```

---

## 17. ライセンス / 貢献

組織ポリシーに従って別途定義。PR/Issue ベースで改善歓迎。

---

以上。AWS 専用ドキュメントとしてこのファイルのみを新リポジトリへ移植すれば最小構成で再現できます。

---

以上。次に進める準備ができたら指示してください。必要なら DynamoDB / OpenAI 移植コード例を追加します。
